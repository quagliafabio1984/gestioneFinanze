import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { Capacitor } from "@capacitor/core";
import { App as CapApp } from "@capacitor/app";
import { Haptics, ImpactStyle } from "@capacitor/haptics";
import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, ReferenceLine
} from "recharts";
import {
  CalendarDays, Briefcase, Heart, PiggyBank, Receipt, Settings2,
  Plus, Trash2, Pencil, ChevronLeft, ChevronRight, X, Check,
  TrendingUp, TrendingDown, Wallet, Landmark, Compass, AlertTriangle,
  MoreHorizontal, Download, Upload, ChevronDown, ArrowDownLeft, ArrowUpRight, Repeat
} from "lucide-react";

const MONTH_NAMES = ["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"];
const WEEK_DAYS = ["Lun","Mar","Mer","Gio","Ven","Sab","Dom"];
const EXPENSE_CATEGORIES = ["Mutuo","Affitto","Bollette","Prestiti","Assicurazioni","Spese condominio","Mensa/Scuola","Abbonamenti","Spesa","Tasse","Altro"];

const fmtEUR = (n) => new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" }).format(Number.isFinite(n) ? n : 0);
const fmtEURCompact = (n) => new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(Number.isFinite(n) ? n : 0);
const fmtDate = (d) => d.toLocaleDateString("it-IT", { day: "2-digit", month: "2-digit", year: "numeric" });
const fmtMonthKey = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
const fmtMonthLabel = (key) => {
  const [y, m] = key.split("-").map(Number);
  return `${MONTH_NAMES[m - 1]} ${y}`;
};
const parseDate = (s) => new Date(`${s}T00:00:00`);
const dateKey = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const monthKeyToDate = (mese, day) => {
  const [y, m] = mese.split("-").map(Number);
  const lastDay = new Date(y, m, 0).getDate();
  return new Date(y, m - 1, Math.min(day, lastDay));
};
const startOfMonth = (d) => new Date(d.getFullYear(), d.getMonth(), 1);
const endOfMonth = (d) => new Date(d.getFullYear(), d.getMonth() + 1, 0);
const addMonths = (d, n) => new Date(d.getFullYear(), d.getMonth() + n, d.getDate());
const addMonthsPreserveDay = (base, n) => {
  const target = new Date(base.getFullYear(), base.getMonth() + n, 1);
  const last = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
  target.setDate(Math.min(base.getDate(), last));
  return target;
};
const addYearsPreserveDay = (base, n) => {
  const y = base.getFullYear() + n;
  const last = new Date(y, base.getMonth() + 1, 0).getDate();
  return new Date(y, base.getMonth(), Math.min(base.getDate(), last));
};
const newId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

// ---------------------------------------------------------------------------
// Integrazione smartphone (Capacitor): feedback aptico, tasto Indietro di
// Android, formattazione compatta degli importi per le celle del calendario.
// Su browser/desktop queste funzioni sono innocue (no-op).
// ---------------------------------------------------------------------------
const IS_NATIVE = Capacitor.isNativePlatform();
const haptic = (style = "light") => {
  if (!IS_NATIVE) return;
  const map = { light: ImpactStyle.Light, medium: ImpactStyle.Medium, heavy: ImpactStyle.Heavy };
  Haptics.impact({ style: map[style] || ImpactStyle.Light }).catch(() => {});
};
// Importo compatto per spazi stretti: 950 -> "950", 1.234 -> "1,2k", 12.500 -> "13k"
const fmtK = (n) => {
  const v = Number.isFinite(n) ? n : 0;
  const a = Math.abs(v);
  const sign = v < 0 ? "-" : "";
  if (a >= 10000) return `${sign}${Math.round(a / 1000)}k`;
  if (a >= 1000) return `${sign}${(a / 1000).toFixed(1).replace(".", ",")}k`;
  return `${sign}${Math.round(a)}`;
};
// Pila dei gestori del tasto Indietro: l'ultimo foglio/finestra aperto si
// chiude per primo, poi si torna al Calendario, poi si esce dall'app.
const backHandlers = [];
function useBackHandler(active, handler) {
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => {
    if (!active) return undefined;
    const fn = () => ref.current();
    backHandlers.push(fn);
    return () => {
      const i = backHandlers.lastIndexOf(fn);
      if (i >= 0) backHandlers.splice(i, 1);
    };
  }, [active]);
}
const DATA_KEYS = ["settings", "freelance", "spouse", "extra", "expenses", "prelievi", "redditoDipendente", "giroconti", "speseLavorative"];

// Genera l'elenco di chiavi mese ("YYYY-MM") da startKey a endKey inclusi,
// usato per creare piu' voci di fatturato identiche (clienti a corpo).
function monthKeysInRange(startKey, endKey) {
  const [ys, ms] = startKey.split("-").map(Number);
  const [ye, me] = endKey.split("-").map(Number);
  const out = [];
  let y = ys, m = ms;
  let guard = 0;
  while ((y < ye || (y === ye && m <= me)) && guard < 240) {
    out.push(`${y}-${String(m).padStart(2, "0")}`);
    m++;
    if (m > 12) { m = 1; y++; }
    guard++;
  }
  return out;
}

// Anni disponibili in una lista (per popolare i filtri "per anno"), piu'
// recenti prima. extractYear riceve l'elemento e restituisce l'anno come
// stringa (es. da "2026-03" o "2026-03-15").
function availableYears(list, extractYear) {
  const years = new Set(list.map(extractYear).filter(Boolean));
  return Array.from(years).sort((a, b) => b.localeCompare(a));
}
const EPOCH = new Date(2000, 0, 1);

function calcIrpef(reddito, s) {
  const r = Math.max(0, Number(reddito) || 0);
  const brackets = [
    { limit: s.scaglione1Fino, rate: s.aliquota1 },
    { limit: s.scaglione2Fino, rate: s.aliquota2 },
    { limit: Infinity, rate: s.aliquota3 },
  ];
  let tax = 0;
  let prev = 0;
  for (const b of brackets) {
    if (r <= prev) break;
    const taxable = Math.min(r, b.limit) - prev;
    tax += (taxable * b.rate) / 100;
    prev = b.limit;
  }
  return tax;
}

function occurrencesInRange(item, rangeStart, rangeEnd) {
  const base = parseDate(item.data);
  // Se il campo periodicita' manca o e' vuoto (es. record piu' vecchi di
  // quando questo campo e' stato introdotto), va trattato come "una_tantum":
  // altrimenti non corrisponde a nessuno dei tre casi gestiti sotto e il
  // movimento sparirebbe silenziosamente da tutti i calcoli, pur restando
  // visibile in tabella grazie al fallback usato solo per la visualizzazione.
  const periodicita = item.periodicita || "una_tantum";
  const hardEnd = item.dataFine ? parseDate(item.dataFine) : null;
  const effectiveEnd = hardEnd && hardEnd < rangeEnd ? hardEnd : rangeEnd;
  const out = [];
  if (periodicita === "una_tantum") {
    if (base >= rangeStart && base <= rangeEnd) out.push(base);
    return out;
  }
  if (periodicita === "mensile") {
    for (let i = 0; i < 1200; i++) {
      const occ = addMonthsPreserveDay(base, i);
      if (occ > effectiveEnd) break;
      if (occ >= rangeStart) out.push(occ);
    }
    return out;
  }
  if (periodicita === "annuale") {
    for (let i = 0; i < 100; i++) {
      const occ = addYearsPreserveDay(base, i);
      if (occ > effectiveEnd) break;
      if (occ >= rangeStart) out.push(occ);
    }
    return out;
  }
  return out;
}

const DEFAULT_SETTINGS = {
  saldoIniziale: 0,
  saldoInizialeData: dateKey(new Date()),
  escludiStoricoDalSaldo: true,
  includiStoricoPerTasse: true,
  dataRiferimentoTasse: dateKey(new Date()),
  giornoIncassoFreelance: 5,
  giornoStipendioMoglie: 27,
  coeffRedditivita: 78,
  aliquotaImposta: 5,
  aliquotaInps: 26.07,
  regimeDefault: "forfettario",
  aliquotaIva: 22,
  aliquotaRitenuta: 20,
  scaglione1Fino: 28000,
  aliquota1: 23,
  scaglione2Fino: 50000,
  aliquota2: 35,
  aliquota3: 43,
  aliquotaInpsDipendente: 9.19,
  // Scadenzario fiscale (acconti/saldo): percentuali e date standard,
  // ma modificabili perche' cambiano spesso per decreto di anno in anno.
  aliquotaAcconto: 100,
  quotaPrimoAcconto: 40,
  scadenzaSaldoGiorno: 30,
  scadenzaSaldoMese: 6,
  scadenzaSecondoAccontoGiorno: 30,
  scadenzaSecondoAccontoMese: 11,
  aliquotaAccontoIva: 100,
  scadenzaAccontoIvaGiorno: 27,
  scadenzaAccontoIvaMese: 12,
  // Liquidazioni IVA trimestrali (per chi versa l'IVA a trimestre, non a
  // saldo/acconto come IRPEF/INPS): scadenze standard con maggiorazione
  // dell'1% per le prime tre, la quarta si versa di norma con il saldo
  // annuale. Tutto modificabile perche' le date possono slittare.
  scadenzaIva1Giorno: 16,
  scadenzaIva1Mese: 5,
  scadenzaIva2Giorno: 20,
  scadenzaIva2Mese: 8,
  scadenzaIva3Giorno: 16,
  scadenzaIva3Mese: 11,
  scadenzaIva4Giorno: 16,
  scadenzaIva4Mese: 3,
  ivaTrimestraleMaggiorazione: 1,
  // Previsioni conto familiare: parametri per individuare fasi critiche.
  previsioneMesiStagnazione: 3,
  previsioneSogliaCritica: 500,
  previsioneOrizzonteAnni: 3,
};

// Un fatturato e' "eleggibile" per il conteggio aggregato delle tasse
// (fondo tasse, riepiloghi INPS/IRPEF) in base al flag includiStoricoPerTasse:
// se true (default) conta sempre; se false, solo dalla data di riferimento
// fiscale in poi. Questa data e' indipendente da quella di reset del conto
// familiare: le due cose non devono per forza coincidere.
function isEligibleForTax(f, settings) {
  if (settings.includiStoricoPerTasse) return true;
  return monthKeyToDate(f.mese, 1) >= parseDate(settings.dataRiferimentoTasse);
}

// Quota di una spesa professionale che riduce il reddito imponibile (in base
// alla % di deducibilita' impostata sul singolo movimento, default 100%).
// Vale solo per il regime ordinario: il forfettario non deduce costi reali.
// Se e' impostato un "valore totale fattura" (pagamento a rate), la base di
// calcolo e' quel totale, contato una sola volta alla data della fattura,
// non ad ogni rata: l'importo della singola rata resta solo un movimento
// di cassa e non influenza la deduzione.
function speseCostoDeducibileInRange(spese, rangeStart, rangeEnd) {
  return spese.reduce((sum, s) => {
    const percDed = s.percDeduzione !== undefined && s.percDeduzione !== "" && s.percDeduzione !== null ? Number(s.percDeduzione) : 100;
    const totaleFattura = s.valoreTotaleFattura !== undefined && s.valoreTotaleFattura !== "" && s.valoreTotaleFattura !== null ? Number(s.valoreTotaleFattura) : null;
    if (totaleFattura !== null) {
      const dataFattura = parseDate(s.data);
      if (dataFattura >= rangeStart && dataFattura <= rangeEnd) {
        return sum + totaleFattura * (percDed / 100);
      }
      return sum;
    }
    const occorrenze = occurrencesInRange(s, rangeStart, rangeEnd).length;
    if (occorrenze === 0) return sum;
    return sum + occorrenze * (Number(s.importo) || 0) * (percDed / 100);
  }, 0);
}

// IVA detraibile sugli acquisti professionali: importo della spesa (al netto,
// come i costi deducibili) per l'aliquota IVA generale, per la % di
// detraibilita' impostata sul singolo movimento (default 100%). Stessa
// logica del "valore totale fattura" descritta sopra.
function speseIvaCreditoInRange(spese, rangeStart, rangeEnd, aliquotaIva) {
  return spese.reduce((sum, s) => {
    const percDetr = s.percDetrazioneIva !== undefined && s.percDetrazioneIva !== "" && s.percDetrazioneIva !== null ? Number(s.percDetrazioneIva) : 100;
    const totaleFattura = s.valoreTotaleFattura !== undefined && s.valoreTotaleFattura !== "" && s.valoreTotaleFattura !== null ? Number(s.valoreTotaleFattura) : null;
    if (totaleFattura !== null) {
      const dataFattura = parseDate(s.data);
      if (dataFattura >= rangeStart && dataFattura <= rangeEnd) {
        const ivaTotaleFattura = (totaleFattura * aliquotaIva) / 100;
        return sum + ivaTotaleFattura * (percDetr / 100);
      }
      return sum;
    }
    const occorrenze = occurrencesInRange(s, rangeStart, rangeEnd).length;
    if (occorrenze === 0) return sum;
    const ivaUnitaria = ((Number(s.importo) || 0) * aliquotaIva) / 100;
    return sum + occorrenze * ivaUnitaria * (percDetr / 100);
  }, 0);
}

async function loadKey(key, fallback) {
  try {
    const r = await window.storage.get(key);
    return r ? JSON.parse(r.value) : fallback;
  } catch {
    return fallback;
  }
}
async function saveKey(key, value) {
  try {
    await window.storage.set(key, JSON.stringify(value));
  } catch (e) {
    console.error("Errore di salvataggio", key, e);
  }
}

export default function App() {
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("dashboard");
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [freelance, setFreelance] = useState([]);
  const [spouse, setSpouse] = useState([]);
  const [extra, setExtra] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [prelievi, setPrelievi] = useState([]);
  const [giroconti, setGiroconti] = useState([]);
  const [speseLavorative, setSpeseLavorative] = useState([]);
  const [redditoDipendente, setRedditoDipendente] = useState([]);
  const [currentMonth, setCurrentMonth] = useState(startOfMonth(new Date()));
  const [dayFilter, setDayFilter] = useState(null);
  const [saveTick, setSaveTick] = useState(0);
  const [moreOpen, setMoreOpen] = useState(false);
  const [toast, setToast] = useState(null); // { text, actionLabel, action }
  const [jumpItems, setJumpItems] = useState([]);
  const toastTimer = useRef(null);
  const tabRef = useRef(tab);
  const mainRef = useRef(null);
  tabRef.current = tab;

  const notify = useCallback((text, actionLabel, action) => {
    clearTimeout(toastTimer.current);
    setToast({ text, actionLabel, action, key: Date.now() });
    toastTimer.current = setTimeout(() => setToast(null), action ? 6000 : 2600);
  }, []);

  const goTab = useCallback((id) => {
    setTab(id);
    setMoreOpen(false);
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  }, []);

  // Tasto Indietro di Android: chiude prima fogli e finestre, poi torna al
  // Calendario, infine esce dall'app (comportamento standard delle app).
  useEffect(() => {
    if (!IS_NATIVE) return undefined;
    const sub = CapApp.addListener("backButton", () => {
      if (backHandlers.length) { backHandlers[backHandlers.length - 1](); return; }
      if (tabRef.current !== "dashboard") { setTab("dashboard"); window.scrollTo(0, 0); return; }
      CapApp.exitApp();
    });
    return () => { sub.then((h) => h.remove()).catch(() => {}); };
  }, []);
  useBackHandler(moreOpen, () => setMoreOpen(false));

  // Su smartphone le tabelle diventano schede impilate: ogni cella riceve
  // l'intestazione della sua colonna come etichetta (data-label), letta via
  // CSS. Lo stesso osservatore raccoglie i titoli dei pannelli per la barra
  // di navigazione rapida nelle schede lunghe (Partita IVA, Previsioni...).
  useEffect(() => {
    const root = mainRef.current;
    if (!root) return undefined;
    let raf = 0;
    const run = () => {
      raf = 0;
      root.querySelectorAll("table").forEach((table) => {
        const heads = Array.from(table.querySelectorAll("thead th")).map((th) => th.textContent.trim());
        table.querySelectorAll("tbody tr").forEach((tr) => {
          Array.from(tr.children).forEach((td, i) => {
            const label = heads[i] || "";
            if (td.getAttribute("data-label") !== label) td.setAttribute("data-label", label);
            const isActions = !!td.querySelector(".row-actions");
            if (isActions !== td.classList.contains("cell-actions")) td.classList.toggle("cell-actions", isActions);
          });
        });
      });
      const panels = Array.from(root.querySelectorAll(".panel")).filter((p) => p.querySelector(".panel-title"));
      const titles = panels.map((p, i) => {
        p.setAttribute("data-jump", String(i));
        return p.querySelector(".panel-title").textContent.replace(/\s*\(.*?\)\s*/g, " ").trim();
      });
      setJumpItems((prev) => (prev.join("|") === titles.join("|") ? prev : titles));
    };
    const schedule = () => { if (!raf) raf = requestAnimationFrame(run); };
    schedule();
    const mo = new MutationObserver(schedule);
    mo.observe(root, { childList: true, subtree: true, characterData: true });
    return () => { mo.disconnect(); if (raf) cancelAnimationFrame(raf); };
  }, [loading]);

  useEffect(() => {
    (async () => {
      const [s, f, sp, ex, exp, pr, rd, gc, sl] = await Promise.all([
        loadKey("settings", DEFAULT_SETTINGS),
        loadKey("freelance", []),
        loadKey("spouse", []),
        loadKey("extra", []),
        loadKey("expenses", []),
        loadKey("prelievi", []),
        loadKey("redditoDipendente", []),
        loadKey("giroconti", []),
        loadKey("speseLavorative", []),
      ]);
      setSettings({ ...DEFAULT_SETTINGS, ...s });
      setFreelance(f);
      setSpouse(sp);
      setExtra(ex);
      setExpenses(exp);
      setPrelievi(pr);
      setRedditoDipendente(rd);
      setGiroconti(gc);
      setSpeseLavorative(sl);
      setLoading(false);
    })();
  }, []);

  const flashSaved = () => {
    setSaveTick((t) => t + 1);
  };

  const updateSettings = (patch) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      saveKey("settings", next).then(flashSaved);
      return next;
    });
  };

  function makeCollectionApi(list, setList, storageKey) {
    // Se add/update/remove vengono chiamate piu' volte di seguito nello stesso
    // gestore evento (es. "ripeti fino al mese"), ognuna deve vedere le
    // modifiche delle precedenti: "list" (il prop di questo render) da solo
    // non basta, quindi teniamo un accumulatore locale "current" aggiornato
    // in modo sincrono, e salviamo su storage una sola volta a fine batch
    // (microtask) con il valore finale corretto, invece di una volta per
    // ogni chiamata con dati parziali che si sovrascrivono a vicenda.
    let current = list;
    let saveScheduled = false;
    const scheduleSave = () => {
      if (saveScheduled) return;
      saveScheduled = true;
      Promise.resolve().then(() => {
        saveScheduled = false;
        saveKey(storageKey, current).then(flashSaved);
      });
    };
    const persist = (next) => {
      current = next;
      setList(next);
      scheduleSave();
    };
    const add = (item) => {
      persist([...current, { ...item, id: newId() }]);
    };
    const update = (id, patch) => {
      persist(current.map((it) => (it.id === id ? { ...it, ...patch } : it)));
    };
    const remove = (id) => {
      const removed = current.find((it) => it.id === id);
      persist(current.filter((it) => it.id !== id));
      haptic("medium");
      if (removed) {
        notify("Voce eliminata", "Annulla", () => {
          setList((prev) => {
            if (prev.some((it) => it.id === removed.id)) return prev;
            const next = [...prev, removed];
            saveKey(storageKey, next).then(flashSaved);
            return next;
          });
          haptic();
        });
      }
    };
    return { add, update, remove };
  }

  const freelanceApi = makeCollectionApi(freelance, setFreelance, "freelance");
  const spouseApi = makeCollectionApi(spouse, setSpouse, "spouse");
  const extraApi = makeCollectionApi(extra, setExtra, "extra");
  const expensesApi = makeCollectionApi(expenses, setExpenses, "expenses");
  const prelieviApi = makeCollectionApi(prelievi, setPrelievi, "prelievi");
  const giroconoApi = makeCollectionApi(giroconti, setGiroconti, "giroconti");
  const speseLavorativeApi = makeCollectionApi(speseLavorative, setSpeseLavorative, "speseLavorative");
  const redditoDipendenteApi = makeCollectionApi(redditoDipendente, setRedditoDipendente, "redditoDipendente");

  const resetAll = async () => {
    if (!window.confirm("Cancellare tutti i dati inseriti? L'operazione non e' reversibile.")) return;
    await Promise.all(DATA_KEYS.map((k) => window.storage.delete(k).catch(() => {})));
    setSettings(DEFAULT_SETTINGS);
    setFreelance([]);
    setSpouse([]);
    setExtra([]);
    setExpenses([]);
    setPrelievi([]);
    setRedditoDipendente([]);
    setGiroconti([]);
    setSpeseLavorative([]);
  };

  // Backup: esporta tutti i dati in un file JSON (su smartphone si apre il
  // menu Condividi: Drive, email, WhatsApp...) e reimporta da un file.
  const exportData = async () => {
    const payload = {
      app: "bilancio-famiglia", formato: 1, esportatoIl: new Date().toISOString(),
      dati: { settings, freelance, spouse, extra, expenses, prelievi, redditoDipendente, giroconti, speseLavorative },
    };
    const json = JSON.stringify(payload, null, 2);
    const fileName = `bilancio-backup-${dateKey(new Date())}.json`;
    try {
      if (IS_NATIVE) {
        const res = await Filesystem.writeFile({ path: fileName, data: json, directory: Directory.Cache, encoding: Encoding.UTF8 });
        await Share.share({ title: "Backup Bilancio di famiglia", files: [res.uri], dialogTitle: "Salva o invia il backup" });
      } else {
        const url = URL.createObjectURL(new Blob([json], { type: "application/json" }));
        const a = document.createElement("a");
        a.href = url; a.download = fileName; a.click();
        setTimeout(() => URL.revokeObjectURL(url), 2000);
      }
    } catch (e) {
      if (!String(e && e.message).toLowerCase().includes("cancel")) notify("Esportazione non riuscita: riprova");
    }
  };

  const importData = async (file) => {
    if (!file) return;
    let parsed;
    try { parsed = JSON.parse(await file.text()); } catch { notify("Il file scelto non e' un backup valido"); return; }
    const d = parsed && (parsed.dati || parsed.data || parsed);
    if (!d || typeof d !== "object" || !DATA_KEYS.some((k) => k in d)) { notify("Il file scelto non e' un backup di Bilancio di famiglia"); return; }
    const quando = parsed.esportatoIl ? ` del ${fmtDate(new Date(parsed.esportatoIl))}` : "";
    if (!window.confirm(`Sostituire tutti i dati attuali con quelli del backup${quando}?`)) return;
    const arr = (k) => (Array.isArray(d[k]) ? d[k] : []);
    const nextSettings = { ...DEFAULT_SETTINGS, ...(d.settings || {}) };
    const lists = {
      freelance: [arr("freelance"), setFreelance], spouse: [arr("spouse"), setSpouse], extra: [arr("extra"), setExtra],
      expenses: [arr("expenses"), setExpenses], prelievi: [arr("prelievi"), setPrelievi],
      redditoDipendente: [arr("redditoDipendente"), setRedditoDipendente], giroconti: [arr("giroconti"), setGiroconti],
      speseLavorative: [arr("speseLavorative"), setSpeseLavorative],
    };
    setSettings(nextSettings);
    await saveKey("settings", nextSettings);
    await Promise.all(Object.entries(lists).map(([k, [val, setter]]) => { setter(val); return saveKey(k, val); }));
    haptic("medium");
    notify("Backup ripristinato");
  };

  // Regime ordinario: l'IRPEF e' progressiva e cumulativa su tutti i redditi dell'anno
  // (lavoro dipendente + reddito professionale). Per ogni anno calcoliamo l'IRPEF totale
  // e quella sul solo reddito da dipendente: la differenza e' l'IRPEF marginale
  // attribuibile all'attivita' professionale, poi ripartita sui mesi in proporzione al reddito.
  const yearlyOrdinario = useMemo(() => {
    const map = {};
    freelance.filter((f) => f.regime === "ordinario" && isEligibleForTax(f, settings)).forEach((f) => {
      const year = f.mese.split("-")[0];
      if (!map[year]) map[year] = { redditoProfessionale: 0, redditoImponibileIrpef: 0, ivaTotale: 0, ritenutaTotale: 0 };
      const costi = Number(f.costi) || 0;
      // Reddito professionale lordo (ricavi - costi): e' la base su cui si
      // calcola l'INPS gestione separata.
      const redditoLordo = Math.max(0, (Number(f.fatturato) || 0) - costi);
      // I contributi INPS versati sono deducibili dal reddito imponibile IRPEF
      // (art. 10 TUIR): l'IRPEF si calcola quindi sul reddito al netto dell'INPS,
      // non sul reddito professionale lordo.
      const inpsMese = (redditoLordo * settings.aliquotaInps) / 100;
      const redditoImponibileIrpefMese = Math.max(0, redditoLordo - inpsMese);
      map[year].redditoProfessionale += redditoLordo;
      map[year].redditoImponibileIrpef += redditoImponibileIrpefMese;
      map[year].ivaTotale += Number(f.iva) || 0;
      map[year].ritenutaTotale += Number(f.ritenuta) || 0;
    });
    Object.keys(map).forEach((year) => {
      const rd = redditoDipendente.find((r) => String(r.anno) === year);
      const redditoDip = rd ? Number(rd.importo) || 0 : 0;
      // IRPEF/INPS gia' trattenute dal datore di lavoro sul reddito da dipendente:
      // per default calcolate sugli scaglioni, ma modificabili a mano (campo
      // irpefTrattenuta/inpsTrattenuta) per riflettere eventuali conguagli
      // positivi o negativi fatti in busta paga.
      const irpefDipCalcolata = calcIrpef(redditoDip, settings);
      const irpefDipEffettiva = rd && rd.irpefTrattenuta !== undefined && rd.irpefTrattenuta !== "" && rd.irpefTrattenuta !== null
        ? Number(rd.irpefTrattenuta)
        : irpefDipCalcolata;
      const inpsDipCalcolata = (redditoDip * settings.aliquotaInpsDipendente) / 100;
      const inpsDipEffettiva = rd && rd.inpsTrattenuta !== undefined && rd.inpsTrattenuta !== "" && rd.inpsTrattenuta !== null
        ? Number(rd.inpsTrattenuta)
        : inpsDipCalcolata;
      // Spese professionali (PC, software, ecc.) deducibili dal reddito e IVA
      // detraibile sugli acquisti: riducono la base imponibile IRPEF e l'IVA
      // da versare, secondo le percentuali impostate su ogni singola spesa.
      // Il reddito imponibile "lordo" (map[year].redditoImponibileIrpef) resta
      // invariato per non alterare la ripartizione proporzionale tra fatture,
      // e viene usato solo qui per calcolare l'IRPEF sul reddito "netto".
      const yearStart = new Date(Number(year), 0, 1);
      const yearEnd = new Date(Number(year), 11, 31);
      const costoSpeseAnno = speseCostoDeducibileInRange(speseLavorative, yearStart, yearEnd);
      const ivaCreditoSpeseAnno = speseIvaCreditoInRange(speseLavorative, yearStart, yearEnd, settings.aliquotaIva);
      const redditoImponibileIrpefNetto = Math.max(0, map[year].redditoImponibileIrpef - costoSpeseAnno);
      // IRPEF totale calcolata sul reddito dipendente (lordo, le sue detrazioni
      // sono gia' dentro irpefDipEffettiva) + reddito professionale al netto
      // dell'INPS e delle spese professionali deducibili.
      const irpefTotale = calcIrpef(redditoDip + redditoImponibileIrpefNetto, settings);
      map[year].redditoDipendente = redditoDip;
      map[year].irpefDipendenteCalcolata = irpefDipCalcolata;
      map[year].irpefDipendente = irpefDipEffettiva;
      map[year].inpsDipendenteCalcolata = inpsDipCalcolata;
      map[year].inpsDipendente = inpsDipEffettiva;
      map[year].costoSpeseDeducibili = costoSpeseAnno;
      map[year].redditoImponibileIrpefNetto = redditoImponibileIrpefNetto;
      map[year].ivaCreditoSpese = ivaCreditoSpeseAnno;
      map[year].ivaNetta = Math.max(0, map[year].ivaTotale - ivaCreditoSpeseAnno);
      map[year].irpefProfessionale = Math.max(0, irpefTotale - irpefDipEffettiva);
    });
    return map;
  }, [freelance, redditoDipendente, speseLavorative, settings]);

  const taxCalcEntry = useCallback((f) => {
    if (f.regime === "ordinario") {
      const costi = Number(f.costi) || 0;
      const redditoMese = Math.max(0, (Number(f.fatturato) || 0) - costi);
      const inps = (redditoMese * settings.aliquotaInps) / 100;
      // I contributi INPS sono deducibili dalla base IRPEF (art. 10 TUIR):
      // la quota di IRPEF marginale di questa fattura si calcola sul reddito
      // gia' al netto dell'INPS, coerentemente con l'aggregato annuale.
      const redditoImponibileIrpefMese = Math.max(0, redditoMese - inps);
      const year = f.mese.split("-")[0];
      const agg = yearlyOrdinario[year];
      const quota = agg && agg.redditoImponibileIrpef > 0 ? redditoImponibileIrpefMese / agg.redditoImponibileIrpef : 0;
      const impostaLorda = agg ? agg.irpefProfessionale * quota : 0;
      const ritenuta = Number(f.ritenuta) || 0;
      const imposta = Math.max(0, impostaLorda - ritenuta);
      const iva = Number(f.iva) || 0;
      const incassoNetto = (Number(f.fatturato) || 0) + iva - ritenuta;
      const accantonamento = imposta + inps + iva;
      return { imponibile: redditoMese, redditoImponibileIrpef: redditoImponibileIrpefMese, impostaLorda, imposta, inps, iva, ritenuta, incassoNetto, accantonamento, quotaFamiglia: incassoNetto - accantonamento };
    }
    const imponibile = ((Number(f.fatturato) || 0) * settings.coeffRedditivita) / 100;
    const imposta = (imponibile * settings.aliquotaImposta) / 100;
    const inps = (imponibile * settings.aliquotaInps) / 100;
    const incassoNetto = Number(f.fatturato) || 0;
    const accantonamento = imposta + inps;
    return { imponibile, impostaLorda: imposta, imposta, inps, iva: 0, ritenuta: 0, incassoNetto, accantonamento, quotaFamiglia: incassoNetto - accantonamento };
  }, [settings, yearlyOrdinario]);

  // Saldo REALE del conto "Libero professionista": tutto l'incasso di ogni
  // fattura (non solo la quota tasse) entra qui, meno i pagamenti effettuati
  // all'erario, meno le spese professionali (PC, fondo previdenza, ecc.)
  // pagate dallo stesso conto, meno i giroconti trasferiti al conto familiare.
  // E' questo il conto da cui puoi pagare qualunque cosa legata al lavoro,
  // incluse le tasse: nulla ne esce automaticamente verso la famiglia.
  const saldoContoAlla = useCallback((data) => {
    const incassato = freelance.reduce((sum, f) => {
      const d = monthKeyToDate(f.mese, 1);
      if (d <= data && isEligibleForTax(f, settings)) sum += taxCalcEntry(f).incassoNetto;
      return sum;
    }, 0);
    const pagatoTasse = prelievi.reduce((sum, p) => {
      const occorrenze = occurrencesInRange(p, EPOCH, data).length;
      return sum + occorrenze * (Number(p.importo) || 0);
    }, 0);
    const speseProfessionali = speseLavorative.reduce((sum, s) => {
      const occorrenze = occurrencesInRange(s, EPOCH, data).length;
      return sum + occorrenze * (Number(s.importo) || 0);
    }, 0);
    const trasferitoFamiglia = giroconti.reduce((sum, g) => {
      if (parseDate(g.data) <= data) sum += Number(g.importo) || 0;
      return sum;
    }, 0);
    return incassato - pagatoTasse - speseProfessionali - trasferitoFamiglia;
  }, [freelance, prelievi, speseLavorative, giroconti, taxCalcEntry, settings]);

  // Quanto dovrebbe restare accantonato per le tasse (promemoria/target), al
  // netto di quanto gia' versato: da confrontare col saldo reale per capire
  // se stai intaccando soldi che in realta' servono per le tasse.
  const fondoTasseAlla = useCallback((data) => {
    const accantonato = freelance.reduce((sum, f) => {
      const d = monthKeyToDate(f.mese, 1);
      if (d <= data && isEligibleForTax(f, settings)) sum += taxCalcEntry(f).accantonamento;
      return sum;
    }, 0);
    const pagatoTasse = prelievi.reduce((sum, p) => {
      const occorrenze = occurrencesInRange(p, EPOCH, data).length;
      return sum + occorrenze * (Number(p.importo) || 0);
    }, 0);
    return accantonato - pagatoTasse;
  }, [freelance, prelievi, taxCalcEntry, settings]);

  // Eventi del conto familiare (quello mostrato nel calendario). Tutto
  // l'incasso del libero professionista (tasse, spese professionali comprese)
  // resta sul conto libero professionista: non genera nessun movimento
  // automatico qui. L'unico ponte tra i due conti e' il giroconto esplicito.
  const buildEvents = useCallback((rangeStart, rangeEnd) => {
    const events = [];
    spouse.forEach((s) => {
      const d = monthKeyToDate(s.mese, settings.giornoStipendioMoglie);
      if (d >= rangeStart && d <= rangeEnd) {
        events.push({ id: `sp-${s.id}`, data: d, importo: Number(s.netto) || 0, tipo: "entrata", categoria: "Stipendio", descrizione: `Stipendio ${fmtMonthLabel(s.mese)}` });
      }
    });
    extra.forEach((e) => {
      occurrencesInRange(e, rangeStart, rangeEnd).forEach((d) => {
        events.push({ id: `ex-${e.id}-${dateKey(d)}`, data: d, importo: Number(e.importo) || 0, tipo: "entrata", categoria: "Entrata extra", descrizione: e.descrizione || "Entrata extra" });
      });
    });
    expenses.forEach((x) => {
      occurrencesInRange(x, rangeStart, rangeEnd).forEach((d) => {
        events.push({ id: `us-${x.id}-${dateKey(d)}`, data: d, importo: -Math.abs(Number(x.importo) || 0), tipo: "uscita", categoria: x.categoria || "Altro", descrizione: x.descrizione || "Uscita" });
      });
    });
    giroconti.forEach((g) => {
      const d = parseDate(g.data);
      if (d >= rangeStart && d <= rangeEnd) {
        events.push({ id: `gc-${g.id}`, data: d, importo: Number(g.importo) || 0, tipo: "entrata", categoria: "Giroconto", descrizione: g.nota || "Giroconto dal conto libero professionista" });
      }
    });
    events.sort((a, b) => a.data - b.data);
    return events;
  }, [spouse, extra, expenses, giroconti, settings.giornoStipendioMoglie]);

  const saldoAllaData = useCallback((data) => {
    const start = parseDate(settings.saldoInizialeData);
    if (settings.escludiStoricoDalSaldo) {
      // Comportamento di default: il saldo iniziale e' un punto di partenza
      // pulito, i movimenti datati prima di questa data non influenzano il saldo.
      if (data < start) return settings.saldoIniziale;
      const ev = buildEvents(start, data);
      return settings.saldoIniziale + ev.reduce((s, e) => s + e.importo, 0);
    }
    // Include tutto lo storico: il saldo iniziale viene sommato come rettifica
    // a partire dalla sua data, mentre tutti i movimenti (anche precedenti)
    // concorrono comunque al progressivo.
    const ev = buildEvents(EPOCH, data);
    const rettifica = data >= start ? settings.saldoIniziale : 0;
    return rettifica + ev.reduce((s, e) => s + e.importo, 0);
  }, [buildEvents, settings.saldoIniziale, settings.saldoInizialeData, settings.escludiStoricoDalSaldo]);

  const monthData = useMemo(() => {
    const mStart = startOfMonth(currentMonth);
    const mEnd = endOfMonth(currentMonth);
    const dayBefore = new Date(mStart);
    dayBefore.setDate(dayBefore.getDate() - 1);
    const saldoIniziale = saldoAllaData(dayBefore);
    const events = buildEvents(mStart, mEnd);
    const entrate = events.filter((e) => e.importo > 0).reduce((s, e) => s + e.importo, 0);
    const uscite = events.filter((e) => e.importo < 0).reduce((s, e) => s + e.importo, 0);
    // Il saldo finale si ricava direttamente da saldoAllaData (non da
    // saldoIniziale + entrate/uscite grezze) cosi' rispetta correttamente il
    // flag "escludi storico" anche quando la data di riferimento cade a meta' mese.
    const saldoFinale = saldoAllaData(mEnd);
    return { mStart, mEnd, saldoIniziale, events, entrate, uscite, saldoFinale };
  }, [currentMonth, buildEvents, saldoAllaData]);

  // Solo il saldo del conto familiare: l'andamento del conto libero
  // professionista (fondo tasse) si vede unicamente nella scheda dedicata.
  const chartData = useMemo(() => {
    const out = [];
    for (let i = -3; i <= 8; i++) {
      const m = addMonths(currentMonth, i);
      const mEnd = endOfMonth(m);
      out.push({
        mese: `${MONTH_NAMES[m.getMonth()].slice(0, 3)} ${String(m.getFullYear()).slice(2)}`,
        saldo: Math.round(saldoAllaData(mEnd)),
      });
    }
    return out;
  }, [currentMonth, saldoAllaData]);

  const categoryBreakdown = useMemo(() => {
    const map = {};
    monthData.events.filter((e) => e.importo < 0).forEach((e) => {
      map[e.categoria] = (map[e.categoria] || 0) + Math.abs(e.importo);
    });
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [monthData.events]);

  const fondoTasseOggi = saldoContoAlla(endOfMonth(currentMonth));

  if (loading) {
    return (
      <div style={{ ...styles.app, background: "var(--ink)", alignItems: "center", justifyContent: "center", display: "flex" }}>
        <Landmark size={40} color="var(--gold)" />
      </div>
    );
  }

  const NAV = [
    { id: "dashboard", label: "Calendario", short: "Calendario", icon: CalendarDays },
    { id: "freelance", label: "Libero professionista", short: "Partita IVA", icon: Briefcase },
    { id: "spouse", label: "Entrate moglie", short: "Moglie", icon: Heart },
    { id: "extra", label: "Entrate extra", short: "Extra", icon: PiggyBank },
    { id: "expenses", label: "Uscite", short: "Uscite", icon: Receipt },
    { id: "forecast", label: "Previsioni", short: "Previsioni", icon: Compass },
    { id: "settings", label: "Impostazioni", short: "Impostazioni", icon: Settings2 },
  ];
  // Barra in basso su smartphone: le 4 sezioni piu' usate + "Altro".
  const BOTTOM_IDS = ["dashboard", "freelance", "expenses", "forecast"];
  const MORE_IDS = ["spouse", "extra", "settings"];
  const currentNav = NAV.find((n) => n.id === tab) || NAV[0];

  return (
    <div style={styles.app}>
      <style>{GLOBAL_CSS}</style>
      <div className="budget-root layout" style={styles.layout}>
        <nav className="sidebar" style={styles.sidebar}>
          <div className="brand" style={styles.brand}>
            <Landmark size={20} color="var(--gold)" />
            <div>
              <div style={styles.brandTitle}>Bilancio</div>
              <div style={styles.brandSub}>di famiglia</div>
            </div>
          </div>
          {NAV.map((n) => {
            const Icon = n.icon;
            const active = tab === n.id;
            return (
              <button
                key={n.id}
                className="navbtn"
                onClick={() => goTab(n.id)}
                style={{ ...styles.navItem, ...(active ? styles.navItemActive : {}) }}
              >
                <Icon size={16} />
                <span>{n.label}</span>
              </button>
            );
          })}
          <div className="sidebar-spacer" style={{ flex: 1 }} />
          <div className="fondo-badge" style={styles.fondoBadge}>
            <div style={{ fontSize: 10, letterSpacing: ".05em", textTransform: "uppercase", opacity: 0.7 }}>Conto libero prof.</div>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 16, fontWeight: 600 }}>{fmtEUR(fondoTasseOggi)}</div>
          </div>
        </nav>

        {/* Intestazione smartphone: titolo sezione + saldo conto professionale */}
        <header className="m-header">
          <div className="m-topbar">
            <div className="m-title">{currentNav.label}</div>
            <button className="m-balance" onClick={() => goTab("freelance")} aria-label="Apri conto libero professionista">
              <span className="m-balance-label">Conto prof.</span>
              <span className="m-balance-value">{fmtEURCompact(fondoTasseOggi)}</span>
            </button>
          </div>
          {jumpItems.length >= 4 && <JumpBar items={jumpItems} tab={tab} />}
        </header>

        <main ref={mainRef} className="main-content" style={styles.main}>
          {tab === "dashboard" && (
            <Dashboard
              currentMonth={currentMonth}
              setCurrentMonth={setCurrentMonth}
              monthData={monthData}
              chartData={chartData}
              categoryBreakdown={categoryBreakdown}
              dayFilter={dayFilter}
              setDayFilter={setDayFilter}
              fondoTasseOggi={fondoTasseOggi}
              settings={settings}
              saldoAllaData={saldoAllaData}
              freelanceApi={freelanceApi}
              spouseApi={spouseApi}
              extraApi={extraApi}
              expensesApi={expensesApi}
              giroconoApi={giroconoApi}
              notify={notify}
            />
          )}
          {tab === "freelance" && (
            <FreelanceTab
              settings={settings}
              updateSettings={updateSettings}
              freelance={freelance}
              api={freelanceApi}
              prelievi={prelievi}
              prelieviApi={prelieviApi}
              giroconti={giroconti}
              giroconoApi={giroconoApi}
              speseLavorative={speseLavorative}
              speseLavorativeApi={speseLavorativeApi}
              taxCalcEntry={taxCalcEntry}
              yearlyOrdinario={yearlyOrdinario}
              redditoDipendente={redditoDipendente}
              redditoDipendenteApi={redditoDipendenteApi}
              fondoTasseAlla={fondoTasseAlla}
              saldoContoAlla={saldoContoAlla}
            />
          )}
          {tab === "spouse" && <SpouseTab spouse={spouse} api={spouseApi} settings={settings} updateSettings={updateSettings} />}
          {tab === "extra" && <RecurringTab title="Entrate extra" hint="Assegni familiari, 730, rimborsi, bonus e altre entrate non continuative." items={extra} api={extraApi} sign="entrata" />}
          {tab === "expenses" && <RecurringTab title="Uscite" hint="Bollette, rate, abbonamenti e ogni altra spesa ricorrente o una tantum." items={expenses} api={expensesApi} sign="uscita" withCategory />}
          {tab === "forecast" && <ForecastTab settings={settings} updateSettings={updateSettings} saldoAllaData={saldoAllaData} saldoContoAlla={saldoContoAlla} fondoTasseAlla={fondoTasseAlla} />}
          {tab === "settings" && <SettingsTab settings={settings} updateSettings={updateSettings} resetAll={resetAll} exportData={exportData} importData={importData} />}
        </main>

        {/* Barra di navigazione in basso (solo smartphone) */}
        <nav className="m-bottomnav" aria-label="Sezioni">
          {BOTTOM_IDS.map((id) => {
            const n = NAV.find((x) => x.id === id);
            const Icon = n.icon;
            const active = tab === id;
            return (
              <button key={id} className={`m-navbtn${active ? " active" : ""}`} onClick={() => { if (!active) haptic(); goTab(id); }} aria-current={active ? "page" : undefined}>
                <span className="m-navicon"><Icon size={21} strokeWidth={active ? 2.3 : 1.8} /></span>
                <span className="m-navlabel">{n.short}</span>
              </button>
            );
          })}
          <button className={`m-navbtn${MORE_IDS.includes(tab) ? " active" : ""}`} onClick={() => { haptic(); setMoreOpen(true); }}>
            <span className="m-navicon"><MoreHorizontal size={21} strokeWidth={MORE_IDS.includes(tab) ? 2.3 : 1.8} /></span>
            <span className="m-navlabel">Altro</span>
          </button>
        </nav>

        {moreOpen && (
          <BottomSheet title="Altre sezioni" onClose={() => setMoreOpen(false)}>
            <div className="sheet-list">
              {MORE_IDS.map((id) => {
                const n = NAV.find((x) => x.id === id);
                const Icon = n.icon;
                return (
                  <button key={id} className={`sheet-item${tab === id ? " active" : ""}`} onClick={() => goTab(id)}>
                    <span className="sheet-item-icon"><Icon size={20} /></span>
                    <span className="sheet-item-label">{n.label}</span>
                    <ChevronRight size={18} className="sheet-item-chev" />
                  </button>
                );
              })}
            </div>
          </BottomSheet>
        )}

        {toast && (
          <div className="toast" key={toast.key} role="status">
            <span>{toast.text}</span>
            {toast.action && (
              <button onClick={() => { toast.action(); setToast(null); }}>{toast.actionLabel}</button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// Foglio che sale dal basso (stile Android/iOS), con maniglia e chiusura
// toccando lo sfondo o con il tasto Indietro.
function BottomSheet({ title, onClose, children }) {
  useBackHandler(true, onClose);
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, []);
  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet" role="dialog" aria-label={title} onClick={(e) => e.stopPropagation()}>
        <div className="sheet-handle" />
        {title && <div className="sheet-title">{title}</div>}
        {children}
      </div>
    </div>
  );
}

// Barra di salto rapido tra i pannelli delle schede lunghe, con
// evidenziazione del pannello attualmente visibile.
function JumpBar({ items, tab }) {
  const [active, setActive] = useState(0);
  const barRef = useRef(null);
  useEffect(() => { setActive(0); }, [tab]);
  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const panels = document.querySelectorAll(".main-content .panel[data-jump]");
        let idx = 0;
        panels.forEach((p) => { if (p.getBoundingClientRect().top < 150) idx = Number(p.getAttribute("data-jump")); });
        setActive(idx);
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => { window.removeEventListener("scroll", onScroll); if (raf) cancelAnimationFrame(raf); };
  }, []);
  useEffect(() => {
    const bar = barRef.current;
    const chip = bar && bar.querySelector(`[data-chip="${active}"]`);
    if (chip) bar.scrollTo({ left: chip.offsetLeft - 16, behavior: "smooth" });
  }, [active]);
  const go = (i) => {
    const el = document.querySelector(`.main-content .panel[data-jump="${i}"]`);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
    setActive(i);
  };
  return (
    <div className="jumpbar" ref={barRef}>
      {items.map((t, i) => (
        <button key={`${i}-${t}`} data-chip={i} className={`jumpchip${i === active ? " active" : ""}`} onClick={() => go(i)}>{t}</button>
      ))}
    </div>
  );
}

function Dashboard({ currentMonth, setCurrentMonth, monthData, chartData, categoryBreakdown, dayFilter, setDayFilter, fondoTasseOggi, settings, saldoAllaData, freelanceApi, spouseApi, extraApi, expensesApi, giroconoApi, notify }) {
  const [quickAdd, setQuickAdd] = useState(null); // { date: Date }

  const displayedEvents = dayFilter
    ? monthData.events.filter((e) => dateKey(e.data) === dateKey(dayFilter))
    : monthData.events;

  // Un movimento contribuisce al saldo progressivo solo se e' successivo alla
  // data di riferimento del saldo iniziale, oppure se il flag "escludi storico"
  // e' disattivato (in quel caso conta sempre).
  const saldoStart = parseDate(settings.saldoInizialeData);
  const contaPerSaldo = (d) => !settings.escludiStoricoDalSaldo || d >= saldoStart;

  let running = monthData.saldoIniziale;
  const rows = monthData.events.map((e) => {
    if (contaPerSaldo(e.data)) running += e.importo;
    return { ...e, saldoDopo: running };
  });
  const filteredRows = dayFilter ? rows.filter((r) => dateKey(r.data) === dateKey(dayFilter)) : rows;

  const gridStart = startOfMonth(currentMonth);
  const offset = (gridStart.getDay() + 6) % 7;
  const daysInMonth = endOfMonth(currentMonth).getDate();
  const cells = [];
  for (let i = 0; i < offset; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(currentMonth.getFullYear(), currentMonth.getMonth(), d));

  const eventsByDay = {};
  monthData.events.forEach((e) => {
    const k = dateKey(e.data);
    if (!eventsByDay[k]) eventsByDay[k] = { entrate: 0, uscite: 0 };
    if (e.importo > 0) eventsByDay[k].entrate += e.importo;
    else eventsByDay[k].uscite += e.importo;
  });

  // Saldo corrente giorno per giorno: usa la stessa funzione saldoAllaData
  // usata per saldo iniziale/finale del mese e per il grafico, cosi' rispetta
  // sempre correttamente il flag "escludi storico", anche quando la data di
  // riferimento cade a meta' del mese visualizzato.
  const balanceByDay = {};
  for (let d = 1; d <= daysInMonth; d++) {
    const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), d);
    balanceByDay[dateKey(date)] = saldoAllaData(date);
  }

  const today = new Date();
  const CATCOLORS = ["#3C6E47", "#B8862E", "#A6402F", "#5A7DA6", "#7A6BA6", "#6B7568", "#3C576B"];

  return (
    <div>
      <SectionHeader
        title="Calendario del mese"
        subtitle="Conto familiare: stipendio, entrate extra, uscite e giroconti dal conto libero professionista, con saldo iniziale, finale e saldo attuale giorno per giorno. Tocca un giorno per vederne i movimenti, tienilo premuto (o usa il tasto +) per aggiungerne uno. Il fatturato del libero professionista si gestisce nella scheda dedicata e non entra qui finche' non fai un giroconto."
      />

      <div className="cards" style={styles.cardsGrid}>
        <MetricCard label="Saldo iniziale" value={fmtEUR(monthData.saldoIniziale)} icon={Wallet} />
        <MetricCard label="Entrate previste" value={fmtEUR(monthData.entrate)} icon={TrendingUp} tone="green" />
        <MetricCard label="Uscite previste" value={fmtEUR(monthData.uscite)} icon={TrendingDown} tone="brick" />
        <MetricCard label="Saldo finale" value={fmtEUR(monthData.saldoFinale)} icon={Landmark} tone={monthData.saldoFinale >= 0 ? "green" : "brick"} />
      </div>

      <div className="panel" style={styles.panel}>
        <div style={styles.monthNav}>
          <button className="iconbtn" style={styles.iconBtn} onClick={() => { setCurrentMonth(addMonths(currentMonth, -1)); setDayFilter(null); }}>
            <ChevronLeft size={18} />
          </button>
          <div className="month-label" style={styles.monthLabel}>{MONTH_NAMES[currentMonth.getMonth()]} {currentMonth.getFullYear()}</div>
          <button className="iconbtn" style={styles.iconBtn} onClick={() => { setCurrentMonth(addMonths(currentMonth, 1)); setDayFilter(null); }}>
            <ChevronRight size={18} />
          </button>
          <button style={styles.linkBtn} onClick={() => { setCurrentMonth(startOfMonth(new Date())); setDayFilter(null); }}>Oggi</button>
        </div>

        <div style={styles.weekRow}>
          {WEEK_DAYS.map((w) => <div key={w} style={styles.weekLabel}>{w}</div>)}
        </div>
        <div className="cal-grid" style={styles.calGrid}>
          {cells.map((d, i) => {
            if (!d) return <div key={i} style={styles.calCellEmpty} />;
            const k = dateKey(d);
            const info = eventsByDay[k];
            const saldoGiorno = balanceByDay[k];
            const isToday = dateKey(d) === dateKey(today);
            const isSelected = dayFilter && dateKey(dayFilter) === k;
            return (
              <div
                key={i}
                className="cal-cell"
                role="button"
                tabIndex={0}
                onClick={() => setDayFilter(isSelected ? null : d)}
                onContextMenu={(e) => { e.preventDefault(); setQuickAdd({ date: d }); }}
                onKeyDown={(e) => { if (e.key === "Enter") setDayFilter(isSelected ? null : d); }}
                style={{
                  ...styles.calCell,
                  ...(isToday ? styles.calCellToday : {}),
                  ...(isSelected ? styles.calCellSelected : {}),
                }}
              >
                <button
                  type="button"
                  title="Aggiungi movimento"
                  onClick={(e) => { e.stopPropagation(); setQuickAdd({ date: d }); }}
                  className="cal-addbtn"
                  style={styles.calAddBtn}
                >
                  <Plus size={11} />
                </button>
                <span className="cal-daynum" style={styles.calDayNum}>{d.getDate()}</span>
                {info && (
                  <span className="cal-dots">
                    {info.entrate > 0 && <i className="cal-dot g" />}
                    {info.uscite < 0 && <i className="cal-dot b" />}
                  </span>
                )}
                {info && (
                  <span className="cal-badges" style={styles.calBadges}>
                    {info.entrate > 0 && <span style={styles.calBadgeGreen}>+{Math.round(info.entrate)}</span>}
                    {info.uscite < 0 && <span style={styles.calBadgeBrick}>{Math.round(info.uscite)}</span>}
                  </span>
                )}
                <span className="cal-balance" style={{ ...styles.calBalance, color: saldoGiorno >= 0 ? "var(--green)" : "var(--brick)" }}>
                  <span className="only-desktop-inline">{fmtEURCompact(saldoGiorno)}</span>
                  <span className="only-mobile-inline">{fmtK(saldoGiorno)}</span>
                </span>
              </div>
            );
          })}
        </div>
        <p style={styles.hintText}>Il numero in basso in ogni casella e' il saldo del conto a quella data (in migliaia di euro su smartphone). Tieni premuto un giorno, o usa il tasto +, per aggiungere rapidamente un'entrata o un'uscita.</p>
      </div>

      <div className="panel" style={styles.panel}>
        <div style={styles.panelHeadRow}>
          <div className="panel-title" style={styles.panelTitle}>
            {dayFilter ? `Movimenti del ${fmtDate(dayFilter)}` : "Movimenti del mese"}
          </div>
          {dayFilter && <button style={styles.linkBtn} onClick={() => setDayFilter(null)}>Mostra tutto il mese</button>}
        </div>
        {filteredRows.length === 0 ? (
          <EmptyState text={dayFilter ? "Nessun movimento in questo giorno. Usa il tasto + per aggiungerne uno." : "Nessun movimento in questo mese."} />
        ) : (
          <>
          <MovementList rows={filteredRows} />
          <table className="only-desktop">
            <thead>
              <tr><th>Data</th><th>Descrizione</th><th>Categoria</th><th style={{ textAlign: "right" }}>Importo</th><th style={{ textAlign: "right" }}>Saldo</th></tr>
            </thead>
            <tbody>
              {filteredRows.map((r) => (
                <tr key={r.id}>
                  <td>{fmtDate(r.data)}</td>
                  <td>{r.descrizione}</td>
                  <td style={{ color: "var(--text-muted)" }}>{r.categoria}</td>
                  <td className="num" style={{ color: r.importo >= 0 ? "var(--green)" : "var(--brick)" }}>{fmtEUR(r.importo)}</td>
                  <td className="num">{fmtEUR(r.saldoDopo)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          </>
        )}
      </div>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <div style={{ ...styles.panel, flex: "2 1 420px" }}>
          <div className="panel-title" style={styles.panelTitle}>Andamento saldo familiare</div>
          <div style={{ height: 220 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" />
                <XAxis dataKey="mese" tick={{ fontSize: 11, fill: "var(--text-muted)" }} />
                <YAxis tick={{ fontSize: 11, fill: "var(--text-muted)" }} width={44} tickFormatter={(v) => fmtK(v)} />
                <Tooltip formatter={(v) => fmtEUR(v)} contentStyle={{ fontSize: 12, fontFamily: "var(--font-body)" }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Line type="monotone" dataKey="saldo" name="Saldo conto familiare" stroke="#3C6E47" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div style={{ ...styles.panel, flex: "1 1 240px" }}>
          <div className="panel-title" style={styles.panelTitle}>Uscite del mese per categoria</div>
          {categoryBreakdown.length === 0 ? <EmptyState text="Nessuna uscita nel mese." /> : (
            <div style={{ height: 220 }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={categoryBreakdown} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={1}>
                    {categoryBreakdown.map((_, i) => <Cell key={i} fill={CATCOLORS[i % CATCOLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v) => fmtEUR(v)} contentStyle={{ fontSize: 12 }} />
                  <Legend wrapperStyle={{ fontSize: 11 }} layout="vertical" verticalAlign="middle" align="right" />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      <button
        className="fab"
        onClick={() => { haptic(); setQuickAdd({ date: dayFilter || new Date() }); }}
        aria-label="Nuovo movimento"
      >
        <Plus size={22} strokeWidth={2.4} />
        <span>{dayFilter && dateKey(dayFilter) !== dateKey(new Date()) ? `Nuovo al ${dayFilter.getDate()}/${dayFilter.getMonth() + 1}` : "Nuovo"}</span>
      </button>

      {quickAdd && (
        <QuickAddModal
          notify={notify}
          date={quickAdd.date}
          onClose={() => setQuickAdd(null)}
          settings={settings}
          freelanceApi={freelanceApi}
          spouseApi={spouseApi}
          extraApi={extraApi}
          expensesApi={expensesApi}
          giroconoApi={giroconoApi}
        />
      )}
    </div>
  );
}

// Elenco movimenti per smartphone, raggruppato per giorno come nelle app
// bancarie: descrizione e categoria a sinistra, importo e saldo a destra.
function MovementList({ rows }) {
  const groups = [];
  rows.forEach((r) => {
    const k = dateKey(r.data);
    let g = groups[groups.length - 1];
    if (!g || g.k !== k) { g = { k, data: r.data, items: [] }; groups.push(g); }
    g.items.push(r);
  });
  const iconFor = (r) => (r.categoria === "Giroconto" ? Repeat : r.importo >= 0 ? ArrowDownLeft : ArrowUpRight);
  return (
    <div className="mov-list only-mobile">
      {groups.map((g) => (
        <div key={g.k} className="mov-group">
          <div className="mov-day">
            <span>{g.data.toLocaleDateString("it-IT", { weekday: "long", day: "numeric", month: "long" })}</span>
            <span className="mov-day-bal">{fmtEUR(g.items[g.items.length - 1].saldoDopo)}</span>
          </div>
          {g.items.map((r) => {
            const Icon = iconFor(r);
            const pos = r.importo >= 0;
            return (
              <div key={r.id} className="mov-item">
                <span className={`mov-icon ${pos ? "g" : "b"}`}><Icon size={17} /></span>
                <span className="mov-text">
                  <span className="mov-desc">{r.descrizione}</span>
                  <span className="mov-cat">{r.categoria}</span>
                </span>
                <span className={`mov-amt ${pos ? "g" : "b"}`}>{pos ? "+" : ""}{fmtEUR(r.importo)}</span>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

function QuickAddModal({ date, onClose, settings, freelanceApi, spouseApi, extraApi, expensesApi, giroconoApi, notify }) {
  const [tipo, setTipo] = useState("uscita");
  const [missing, setMissing] = useState(false);
  useBackHandler(true, onClose);
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, []);
  const [form, setForm] = useState({
    descrizione: "", importo: "", periodicita: "una_tantum", dataFine: "", categoria: EXPENSE_CATEGORIES[0],
    nota: "", regime: settings.regimeDefault || "forfettario", costi: "", iva: "", ritenuta: "", netto: "",
  });

  const dataStr = dateKey(date);
  const meseStr = fmtMonthKey(date);

  const TIPI = [
    { id: "uscita", label: "Uscita" },
    { id: "extra", label: "Entrata extra" },
    { id: "giroconto", label: "Giroconto da conto professionista" },
    { id: "fatturato", label: "Fatturato professionista" },
    { id: "moglie", label: "Entrata moglie" },
  ];

  const submit = () => {
    const dataFine = form.periodicita !== "una_tantum" && form.dataFine ? form.dataFine : "";
    const required = tipo === "extra" || tipo === "uscita" ? [form.descrizione, form.importo] : tipo === "moglie" ? [form.netto] : [form.importo];
    if (required.some((v) => !v)) { setMissing(true); haptic("heavy"); return; }
    if (tipo === "extra") {
      if (!form.descrizione || !form.importo) return;
      extraApi.add({ descrizione: form.descrizione, importo: Number(form.importo), periodicita: form.periodicita, data: dataStr, dataFine });
    } else if (tipo === "uscita") {
      if (!form.descrizione || !form.importo) return;
      expensesApi.add({ descrizione: form.descrizione, categoria: form.categoria, importo: Number(form.importo), periodicita: form.periodicita, data: dataStr, dataFine });
    } else if (tipo === "giroconto") {
      if (!form.importo) return;
      giroconoApi.add({ data: dataStr, importo: Number(form.importo), nota: form.nota });
    } else if (tipo === "fatturato") {
      if (!form.importo) return;
      const payload = { mese: meseStr, fatturato: Number(form.importo), regime: form.regime };
      if (form.regime === "ordinario") {
        const importo = Number(form.importo) || 0;
        payload.costi = Number(form.costi) || 0;
        payload.iva = form.iva !== "" ? Number(form.iva) : Math.round(importo * settings.aliquotaIva) / 100;
        payload.ritenuta = form.ritenuta !== "" ? Number(form.ritenuta) : Math.round(importo * settings.aliquotaRitenuta) / 100;
      } else {
        payload.costi = 0;
        payload.iva = 0;
        payload.ritenuta = 0;
      }
      freelanceApi.add(payload);
    } else if (tipo === "moglie") {
      if (!form.netto) return;
      spouseApi.add({ mese: meseStr, netto: Number(form.netto) });
    }
    haptic("medium");
    if (notify) notify(tipo === "fatturato" ? "Fattura aggiunta al conto professionale" : "Movimento aggiunto");
    onClose();
  };

  return (
    <div className="modal-backdrop" style={styles.modalBackdrop} onClick={onClose}>
      <div className="modal-panel" role="dialog" style={styles.modalPanel} onClick={(e) => e.stopPropagation()}>
        <div className="sheet-handle only-mobile" />
        <div style={styles.modalHeadRow}>
          <div className="panel-title" style={styles.panelTitle}>Aggiungi movimento — {fmtDate(date)}</div>
          <button className="iconbtn" style={styles.iconBtn} onClick={onClose}><X size={16} /></button>
        </div>

        <div className="modal-type-row" style={styles.modalTypeRow}>
          {TIPI.map((t) => (
            <button
              key={t.id}
              onClick={() => { setTipo(t.id); setMissing(false); }}
              style={{ ...styles.pillBtn, ...(tipo === t.id ? styles.pillBtnActive : {}) }}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div style={styles.modalFields}>
          {(tipo === "extra" || tipo === "uscita") && (
            <>
              <Field label="Descrizione">
                <input type="text" value={form.descrizione} onChange={(e) => setForm({ ...form, descrizione: e.target.value })} placeholder={tipo === "extra" ? "Assegno familiare" : "Bolletta luce"} style={{ width: "100%" }} />
              </Field>
              {tipo === "uscita" && (
                <Field label="Tipologia">
                  <select value={form.categoria} onChange={(e) => setForm({ ...form, categoria: e.target.value })}>
                    {EXPENSE_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </Field>
              )}
              <Field label="Importo (EUR)">
                <input type="number" step="0.01" value={form.importo} onChange={(e) => setForm({ ...form, importo: e.target.value })} placeholder="0,00" style={{ width: 130 }} />
              </Field>
              <Field label="Periodicita">
                <select value={form.periodicita} onChange={(e) => setForm({ ...form, periodicita: e.target.value })}>
                  <option value="una_tantum">Una tantum</option>
                  <option value="mensile">Mensile</option>
                  <option value="annuale">Annuale</option>
                </select>
              </Field>
              {form.periodicita !== "una_tantum" && (
                <Field label="Data fine (opzionale)">
                  <input type="date" value={form.dataFine} onChange={(e) => setForm({ ...form, dataFine: e.target.value })} min={dataStr} />
                </Field>
              )}
            </>
          )}

          {tipo === "giroconto" && (
            <>
              <Field label="Importo (EUR)">
                <input type="number" step="0.01" value={form.importo} onChange={(e) => setForm({ ...form, importo: e.target.value })} placeholder="0,00" style={{ width: 130 }} />
              </Field>
              <Field label="Nota (opzionale)">
                <input type="text" value={form.nota} onChange={(e) => setForm({ ...form, nota: e.target.value })} placeholder="Es. anticipo spese famiglia" style={{ width: "100%" }} />
              </Field>
              <p style={styles.hintText}>Sposta denaro dal conto libero professionista al conto familiare: riduce il saldo di questo conto e aggiunge un'entrata qui in calendario.</p>
            </>
          )}

          {tipo === "fatturato" && (
            <>
              <Field label={`Mese: ${fmtMonthLabel(meseStr)}`}>
                <span style={styles.hintText}>Il mese si ricava dal giorno selezionato nel calendario.</span>
              </Field>
              <Field label="Regime">
                <select value={form.regime} onChange={(e) => setForm({ ...form, regime: e.target.value })}>
                  <option value="forfettario">Forfettario</option>
                  <option value="ordinario">Ordinario</option>
                </select>
              </Field>
              <Field label="Importo fattura (EUR)">
                <input type="number" step="0.01" value={form.importo} onChange={(e) => setForm({ ...form, importo: e.target.value })} placeholder="0,00" style={{ width: 130 }} />
              </Field>
              {form.regime === "ordinario" && (
                <>
                  <Field label="Costi deducibili (EUR)">
                    <input type="number" step="0.01" value={form.costi} onChange={(e) => setForm({ ...form, costi: e.target.value })} placeholder="0,00" style={{ width: 110 }} />
                  </Field>
                  <Field label={`IVA (EUR, vuoto = ${settings.aliquotaIva}% auto)`}>
                    <input type="number" step="0.01" value={form.iva} onChange={(e) => setForm({ ...form, iva: e.target.value })} placeholder="0,00" style={{ width: 110 }} />
                  </Field>
                  <Field label={`Ritenuta (EUR, vuoto = ${settings.aliquotaRitenuta}% auto)`}>
                    <input type="number" step="0.01" value={form.ritenuta} onChange={(e) => setForm({ ...form, ritenuta: e.target.value })} placeholder="0,00" style={{ width: 110 }} />
                  </Field>
                </>
              )}
              <p style={styles.hintText}>Va sul conto libero professionista, non su quello familiare: per portare soldi in famiglia serve poi un giroconto esplicito. Per la gestione completa (costi/IVA/ritenuta di dettaglio) puoi sempre modificare la voce dalla scheda Libero professionista.</p>
            </>
          )}

          {tipo === "moglie" && (
            <Field label={`Netto per ${fmtMonthLabel(meseStr)} (EUR)`}>
              <input type="number" step="0.01" value={form.netto} onChange={(e) => setForm({ ...form, netto: e.target.value })} placeholder="0,00" style={{ width: 130 }} />
            </Field>
          )}
        </div>

        {missing && <p className="form-error">Compila i campi obbligatori: {tipo === "extra" || tipo === "uscita" ? "descrizione e importo" : "importo"}.</p>}
        <div className="modal-footer" style={styles.modalFooter}>
          <button style={styles.ghostBtn} onClick={onClose}><X size={14} /> Annulla</button>
          <button style={styles.primaryBtn} onClick={submit}><Plus size={14} /> Aggiungi</button>
        </div>
      </div>
    </div>
  );
}

function FreelanceTab({ settings, updateSettings, freelance, api, prelievi, prelieviApi, giroconti, giroconoApi, speseLavorative, speseLavorativeApi, taxCalcEntry, yearlyOrdinario, redditoDipendente, redditoDipendenteApi, fondoTasseAlla, saldoContoAlla }) {
  const blank = { mese: fmtMonthKey(new Date()), fatturato: "", regime: settings.regimeDefault || "forfettario", costi: "", iva: "", ritenuta: "", ripetiFino: "" };
  const [form, setForm] = useState(blank);
  const [editId, setEditId] = useState(null);
  const [ivaTouched, setIvaTouched] = useState(false);
  const [ritenutaTouched, setRitenutaTouched] = useState(false);
  const [pData, setPData] = useState(dateKey(new Date()));
  const [pImporto, setPImporto] = useState("");
  const [pTipologia, setPTipologia] = useState("Irpef");
  const [pNota, setPNota] = useState("");
  const [pPeriodicita, setPPeriodicita] = useState("una_tantum");
  const [pDataFine, setPDataFine] = useState("");
  const [pEditId, setPEditId] = useState(null);
  const [gData, setGData] = useState(dateKey(new Date()));
  const [gImporto, setGImporto] = useState("");
  const [gNota, setGNota] = useState("");
  const [gRipetiFino, setGRipetiFino] = useState("");
  const [gEditId, setGEditId] = useState(null);
  const [sData, setSData] = useState(dateKey(new Date()));
  const [sImporto, setSImporto] = useState("");
  const [sCategoria, setSCategoria] = useState("PC/Attrezzatura");
  const [sNota, setSNota] = useState("");
  const [sPeriodicita, setSPeriodicita] = useState("una_tantum");
  const [sDataFine, setSDataFine] = useState("");
  const [sPercDeduzione, setSPercDeduzione] = useState("100");
  const [sPercDetrazioneIva, setSPercDetrazioneIva] = useState("100");
  const [sValoreTotaleFattura, setSValoreTotaleFattura] = useState("");
  const [sEditId, setSEditId] = useState(null);
  const [rdAnno, setRdAnno] = useState(String(new Date().getFullYear()));
  const [rdImporto, setRdImporto] = useState("");
  const [rdIrpef, setRdIrpef] = useState("");
  const [rdInps, setRdInps] = useState("");
  const [rdIrpefTouched, setRdIrpefTouched] = useState(false);
  const [rdInpsTouched, setRdInpsTouched] = useState(false);
  const [rdEditId, setRdEditId] = useState(null);
  const [filtroAnnoFatturato, setFiltroAnnoFatturato] = useState("");
  const [filtroAnnoPagamenti, setFiltroAnnoPagamenti] = useState("");
  const [filtroAnnoSpese, setFiltroAnnoSpese] = useState("");
  const [filtroAnnoGiroconti, setFiltroAnnoGiroconti] = useState("");

  const TIPOLOGIE_TASSE = ["Irpef", "Inps", "Iva", "Altro"];
  const CATEGORIE_SPESE_LAVORATIVE = ["PC/Attrezzatura", "Fondo previdenza", "Software/Abbonamenti", "Formazione", "Assicurazione professionale", "Commercialista", "Altro"];

  // Come per IVA/ritenuta sul fatturato: proponiamo IRPEF e INPS gia'
  // trattenute dal datore di lavoro calcolandole dagli scaglioni/aliquota,
  // ma restano campi modificabili per riflettere eventuali conguagli.
  const onRdImportoChange = (val) => {
    const importo = Number(val) || 0;
    if (!rdIrpefTouched) setRdIrpef(importo ? String(Math.round(calcIrpef(importo, settings) * 100) / 100) : "");
    if (!rdInpsTouched) setRdInps(importo ? String(Math.round(importo * settings.aliquotaInpsDipendente) / 100) : "");
    setRdImporto(val);
  };

  const resetRdForm = () => {
    setRdEditId(null);
    setRdAnno(String(new Date().getFullYear()));
    setRdImporto("");
    setRdIrpef("");
    setRdInps("");
    setRdIrpefTouched(false);
    setRdInpsTouched(false);
  };

  const submitRd = () => {
    if (!rdAnno || !rdImporto) return;
    const payload = {
      anno: rdAnno,
      importo: Number(rdImporto),
      irpefTrattenuta: rdIrpef !== "" ? Number(rdIrpef) : "",
      inpsTrattenuta: rdInps !== "" ? Number(rdInps) : "",
    };
    if (rdEditId) {
      redditoDipendenteApi.update(rdEditId, payload);
    } else {
      const existing = redditoDipendente.find((r) => String(r.anno) === String(rdAnno));
      if (existing) redditoDipendenteApi.update(existing.id, payload);
      else redditoDipendenteApi.add(payload);
    }
    resetRdForm();
  };

  const startEditRd = (r) => {
    setRdEditId(r.id);
    setRdAnno(String(r.anno));
    setRdImporto(String(r.importo));
    setRdIrpef(r.irpefTrattenuta !== undefined && r.irpefTrattenuta !== "" ? String(r.irpefTrattenuta) : "");
    setRdInps(r.inpsTrattenuta !== undefined && r.inpsTrattenuta !== "" ? String(r.inpsTrattenuta) : "");
    setRdIrpefTouched(true);
    setRdInpsTouched(true);
  };

  const sorted = [...freelance].filter((f) => !filtroAnnoFatturato || f.mese.startsWith(filtroAnnoFatturato)).sort((a, b) => a.mese.localeCompare(b.mese));
  const totaleIncassato = freelance.reduce((s, f) => (isEligibleForTax(f, settings) ? s + taxCalcEntry(f).incassoNetto : s), 0);
  const totalePrelevato = prelievi.reduce((s, p) => {
    const occorrenze = occurrencesInRange(p, EPOCH, new Date()).length;
    return s + occorrenze * (Number(p.importo) || 0);
  }, 0);
  const totaleGiroconti = giroconti.reduce((s, g) => s + (Number(g.importo) || 0), 0);
  const totaleSpeseLavorative = speseLavorative.reduce((s, sp) => {
    const occorrenze = occurrencesInRange(sp, EPOCH, new Date()).length;
    return s + occorrenze * (Number(sp.importo) || 0);
  }, 0);
  // Saldo reale del conto (tutto l'incasso, non solo l'accantonamento) e
  // quanto dovrebbe ancora restare accantonato per le tasse: sono due cose
  // diverse, il primo e' il saldo effettivo, il secondo un promemoria.
  const saldoReale = saldoContoAlla(new Date());
  const fondoTasseNecessario = fondoTasseAlla(new Date());
  const anniOrdinario = Object.keys(yearlyOrdinario).sort();

  // Andamento del conto libero professionista: saldo reale (tutto l'incasso
  // meno tasse/spese/giroconti) confrontato col fondo tasse ancora necessario.
  // Si vede unicamente qui, non nel calendario del conto familiare.
  const businessChartData = useMemo(() => {
    const mesi = freelance.map((f) => f.mese).sort();
    const baseDate = mesi.length ? monthKeyToDate(mesi[0], 1) : new Date();
    const lastDate = mesi.length ? monthKeyToDate(mesi[mesi.length - 1], 1) : new Date();
    const start = addMonths(startOfMonth(baseDate), -1);
    const end = addMonths(startOfMonth(lastDate), 6);
    const out = [];
    let cursor = start;
    let guard = 0;
    while (cursor <= end && guard < 60) {
      const mStart = startOfMonth(cursor);
      const mEnd = endOfMonth(cursor);
      // Movimenti specifici di QUESTO mese (non cumulativi), per mostrarli
      // nel tooltip del grafico: fatturato incassato, pagamenti tasse, spese
      // professionali e giroconti verso la famiglia.
      const movimenti = [];
      freelance.forEach((f) => {
        if (f.mese === fmtMonthKey(cursor)) {
          movimenti.push({ tipo: "Fatturato incassato", dettaglio: f.regime === "ordinario" ? "Ordinario" : "Forfettario", importo: taxCalcEntry(f).incassoNetto });
        }
      });
      prelievi.forEach((p) => {
        occurrencesInRange(p, mStart, mEnd).forEach(() => {
          movimenti.push({ tipo: `Pagamento tasse (${p.tipologia || "Altro"})`, dettaglio: p.nota || "", importo: -(Number(p.importo) || 0) });
        });
      });
      speseLavorative.forEach((s) => {
        occurrencesInRange(s, mStart, mEnd).forEach(() => {
          movimenti.push({ tipo: `Spesa professionale (${s.categoria || "Altro"})`, dettaglio: s.nota || "", importo: -(Number(s.importo) || 0) });
        });
      });
      giroconti.forEach((g) => {
        const d = parseDate(g.data);
        if (d >= mStart && d <= mEnd) {
          movimenti.push({ tipo: "Giroconto verso famiglia", dettaglio: g.nota || "", importo: -(Number(g.importo) || 0) });
        }
      });
      out.push({
        mese: `${MONTH_NAMES[cursor.getMonth()].slice(0, 3)} ${String(cursor.getFullYear()).slice(2)}`,
        saldo: Math.round(saldoContoAlla(mEnd)),
        fondoTasse: Math.round(fondoTasseAlla(mEnd)),
        movimenti,
      });
      cursor = addMonths(cursor, 1);
      guard++;
    }
    return out;
  }, [freelance, prelievi, speseLavorative, giroconti, taxCalcEntry, saldoContoAlla, fondoTasseAlla]);

  // Riepilogo INPS: a differenza dell'IRPEF, i contributi sono calcolabili
  // mese per mese senza bisogno di scaglioni cumulativi, ma raggrupparli per
  // anno aiuta a sapere quanto versare complessivamente (acconti/saldo INPS).
  const yearlyInps = useMemo(() => {
    const map = {};
    freelance.filter((f) => isEligibleForTax(f, settings)).forEach((f) => {
      const year = f.mese.split("-")[0];
      const t = taxCalcEntry(f);
      if (!map[year]) map[year] = { imponibile: 0, inps: 0 };
      map[year].imponibile += t.imponibile;
      map[year].inps += t.inps;
    });
    return map;
  }, [freelance, taxCalcEntry, settings]);
  const anniInps = Object.keys(yearlyInps).sort();

  // Imposta sostitutiva annua per il solo regime forfettario (nell'ordinario
  // l'IRPEF residua e' gia' aggregata correttamente in yearlyOrdinario, al
  // netto delle ritenute: qui la sommiamo per mantenere la stessa correttezza).
  const yearlyForfettarioImposta = useMemo(() => {
    const map = {};
    freelance.filter((f) => f.regime !== "ordinario" && isEligibleForTax(f, settings)).forEach((f) => {
      const year = f.mese.split("-")[0];
      map[year] = (map[year] || 0) + taxCalcEntry(f).imposta;
    });
    return map;
  }, [freelance, taxCalcEntry, settings]);

  // Riepilogo fiscale annuo combinato (imposta dovuta, sia forfettario che
  // ordinario, + INPS + IVA): e' la base su cui si calcolano acconti e saldo
  // dello scadenzario qui sotto.
  const yearlyTaxSummary = useMemo(() => {
    const years = new Set([
      ...Object.keys(yearlyInps),
      ...Object.keys(yearlyOrdinario),
      ...Object.keys(yearlyForfettarioImposta),
    ]);
    const map = {};
    years.forEach((year) => {
      const ord = yearlyOrdinario[year];
      const impostaOrdinaria = ord ? Math.max(0, ord.irpefProfessionale - ord.ritenutaTotale) : 0;
      const impostaForfettaria = yearlyForfettarioImposta[year] || 0;
      map[year] = {
        imposta: impostaOrdinaria + impostaForfettaria,
        inps: (yearlyInps[year] && yearlyInps[year].inps) || 0,
        // Per l'acconto IVA di dicembre si usa l'IVA netta gia' scontata
        // dell'IVA a credito sugli acquisti professionali, non quella lorda.
        iva: (ord && ord.ivaNetta) || 0,
      };
    });
    return map;
  }, [yearlyOrdinario, yearlyInps, yearlyForfettarioImposta]);

  // Scadenzario fiscale: per ogni anno con dati, calcola le scadenze
  // dell'anno successivo (saldo + acconti), secondo il classico meccanismo
  // italiano acconto/saldo. Le percentuali e le date sono configurabili
  // perche' cambiano spesso per decreto di anno in anno.
  const scadenzeFiscali = useMemo(() => {
    // Quanto e' stato effettivamente versato, con una certa tipologia, con
    // scadenza registrata durante un dato anno solare: sono gli acconti che
    // hai gia' pagato per quell'anno, e vanno sottratti dal saldo dovuto.
    const versatoNellAnno = (tipologia, anno) => {
      const start = new Date(anno, 0, 1);
      const end = new Date(anno, 11, 31);
      return prelievi.reduce((sum, p) => {
        if ((p.tipologia || "Altro") !== tipologia) return sum;
        const occorrenze = occurrencesInRange(p, start, end).length;
        return sum + occorrenze * (Number(p.importo) || 0);
      }, 0);
    };

    const rows = [];
    Object.keys(yearlyTaxSummary).sort().forEach((yearStr) => {
      const year = Number(yearStr);
      const s = yearlyTaxSummary[yearStr];
      const nextYear = year + 1;
      // L'acconto dell'anno successivo si calcola sul dovuto complessivo
      // dell'anno (non sul residuo): e' cosi' che funziona il meccanismo
      // storico, indipendentemente da quanto gia' versato.
      const accontoImposta = (s.imposta * settings.aliquotaAcconto) / 100;
      const accontoInps = (s.inps * settings.aliquotaAcconto) / 100;
      const accontoIva = (s.iva * settings.aliquotaAccontoIva) / 100;
      const rata1Imposta = (accontoImposta * settings.quotaPrimoAcconto) / 100;
      const rata2Imposta = accontoImposta - rata1Imposta;
      const rata1Inps = (accontoInps * settings.quotaPrimoAcconto) / 100;
      const rata2Inps = accontoInps - rata1Inps;
      // Il saldo invece va al netto di quanto hai gia' versato come acconto
      // per questo stesso anno (i pagamenti con scadenza nell'anno stesso).
      const saldoImposta = Math.max(0, s.imposta - versatoNellAnno("Irpef", year));
      const saldoInps = Math.max(0, s.inps - versatoNellAnno("Inps", year));
      const dataSaldo = new Date(nextYear, settings.scadenzaSaldoMese - 1, settings.scadenzaSaldoGiorno);
      const dataSecondoAcconto = new Date(nextYear, settings.scadenzaSecondoAccontoMese - 1, settings.scadenzaSecondoAccontoGiorno);
      const dataAccontoIva = new Date(nextYear, settings.scadenzaAccontoIvaMese - 1, settings.scadenzaAccontoIvaGiorno);

      if (saldoImposta > 0 || rata1Imposta > 0) {
        rows.push({ id: `${year}-saldo-irpef`, data: dataSaldo, tipologia: "Irpef", descrizione: `Saldo ${year} (${fmtEUR(saldoImposta)}) + 1° acconto ${nextYear}`, importo: saldoImposta + rata1Imposta });
      }
      if (saldoInps > 0 || rata1Inps > 0) {
        rows.push({ id: `${year}-saldo-inps`, data: dataSaldo, tipologia: "Inps", descrizione: `Saldo INPS ${year} (${fmtEUR(saldoInps)}) + 1° acconto ${nextYear}`, importo: saldoInps + rata1Inps });
      }
      if (rata2Imposta > 0) {
        rows.push({ id: `${year}-secondo-irpef`, data: dataSecondoAcconto, tipologia: "Irpef", descrizione: `2° acconto ${nextYear}`, importo: rata2Imposta });
      }
      if (rata2Inps > 0) {
        rows.push({ id: `${year}-secondo-inps`, data: dataSecondoAcconto, tipologia: "Inps", descrizione: `2° acconto INPS ${nextYear}`, importo: rata2Inps });
      }
      if (accontoIva > 0) {
        rows.push({ id: `${year}-acconto-iva`, data: dataAccontoIva, tipologia: "Iva", descrizione: `Acconto IVA ${nextYear}`, importo: accontoIva });
      }
    });

    // Liquidazioni IVA trimestrali (per chi versa a trimestre, non a saldo
    // annuale): a differenza di acconto/saldo IRPEF/INPS, si basano
    // sull'IVA realmente incassata/detratta in QUEL trimestre, non
    // sull'anno precedente. Le prime tre hanno la maggiorazione impostata
    // (di norma 1%), la quarta si versa di regola col saldo annuale.
    const scadenzeTrimestre = [
      { giorno: settings.scadenzaIva1Giorno, mese: settings.scadenzaIva1Mese, stessoAnno: true },
      { giorno: settings.scadenzaIva2Giorno, mese: settings.scadenzaIva2Mese, stessoAnno: true },
      { giorno: settings.scadenzaIva3Giorno, mese: settings.scadenzaIva3Mese, stessoAnno: true },
      { giorno: settings.scadenzaIva4Giorno, mese: settings.scadenzaIva4Mese, stessoAnno: false },
    ];
    const anniConFatturato = new Set(freelance.map((f) => f.mese.split("-")[0]));
    anniConFatturato.forEach((yearStr) => {
      const year = Number(yearStr);
      for (let q = 1; q <= 4; q++) {
        const meseInizio = (q - 1) * 3;
        const qStart = new Date(year, meseInizio, 1);
        const qEnd = new Date(year, meseInizio + 3, 0);
        const ivaDebito = freelance
          .filter((f) => f.regime === "ordinario" && isEligibleForTax(f, settings))
          .filter((f) => { const d = monthKeyToDate(f.mese, 1); return d >= qStart && d <= qEnd; })
          .reduce((sum, f) => sum + taxCalcEntry(f).iva, 0);
        const ivaCredito = speseIvaCreditoInRange(speseLavorative, qStart, qEnd, settings.aliquotaIva);
        const ivaNettaTrimestre = Math.max(0, ivaDebito - ivaCredito);
        if (ivaNettaTrimestre <= 0) continue;
        const info = scadenzeTrimestre[q - 1];
        const maggiorazione = info.stessoAnno ? (ivaNettaTrimestre * settings.ivaTrimestraleMaggiorazione) / 100 : 0;
        const importo = ivaNettaTrimestre + maggiorazione;
        const dataScadenza = new Date(info.stessoAnno ? year : year + 1, info.mese - 1, info.giorno);
        rows.push({
          id: `${year}-iva-trim-${q}`,
          data: dataScadenza,
          tipologia: "Iva",
          descrizione: `Liquidazione IVA ${q}° trimestre ${year}${maggiorazione > 0 ? ` (incl. maggiorazione ${settings.ivaTrimestraleMaggiorazione}%)` : ""}`,
          importo,
        });
      }
    });

    return rows.sort((a, b) => a.data - b.data);
  }, [yearlyTaxSummary, settings, prelievi, freelance, speseLavorative, taxCalcEntry]);

  // Quando l'utente scrive l'importo fattura, propone IVA e ritenuta calcolate
  // dalle aliquote impostate, ma restano campi separati e modificabili a mano:
  // se l'utente li tocca direttamente, l'auto-calcolo smette di sovrascriverli.
  const onFatturatoChange = (val) => {
    const next = { ...form, fatturato: val };
    const importo = Number(val) || 0;
    if (form.regime === "ordinario") {
      if (!ivaTouched) next.iva = importo ? String(Math.round(importo * settings.aliquotaIva) / 100) : "";
      if (!ritenutaTouched) next.ritenuta = importo ? String(Math.round(importo * settings.aliquotaRitenuta) / 100) : "";
    }
    setForm(next);
  };

  const onRegimeChange = (regime) => {
    setIvaTouched(false);
    setRitenutaTouched(false);
    const importo = Number(form.fatturato) || 0;
    if (regime === "ordinario" && importo) {
      setForm({ ...form, regime, iva: String(Math.round(importo * settings.aliquotaIva) / 100), ritenuta: String(Math.round(importo * settings.aliquotaRitenuta) / 100) });
    } else {
      setForm({ ...form, regime, iva: "", ritenuta: "" });
    }
  };

  const resetForm = () => {
    setForm(blank);
    setIvaTouched(false);
    setRitenutaTouched(false);
    setEditId(null);
  };

  const submit = () => {
    if (!form.mese || !form.fatturato) return;
    const payload = { mese: form.mese, fatturato: Number(form.fatturato), regime: form.regime };
    if (form.regime === "ordinario") {
      payload.costi = Number(form.costi) || 0;
      payload.iva = Number(form.iva) || 0;
      payload.ritenuta = Number(form.ritenuta) || 0;
    } else {
      payload.costi = 0;
      payload.iva = 0;
      payload.ritenuta = 0;
    }
    if (editId) {
      api.update(editId, payload);
    } else if (form.ripetiFino && form.ripetiFino > form.mese) {
      // Cliente a corpo: stesso importo ripetuto su piu' mesi consecutivi,
      // una voce distinta per ognuno (restano modificabili singolarmente).
      monthKeysInRange(form.mese, form.ripetiFino).forEach((mese) => {
        api.add({ ...payload, mese });
      });
    } else {
      api.add(payload);
    }
    resetForm();
  };

  const startEdit = (f) => {
    setEditId(f.id);
    setIvaTouched(true);
    setRitenutaTouched(true);
    setForm({
      mese: f.mese,
      fatturato: String(f.fatturato),
      regime: f.regime || "forfettario",
      costi: String(f.costi || ""),
      iva: String(f.iva || ""),
      ritenuta: String(f.ritenuta || ""),
      ripetiFino: "",
    });
  };

  return (
    <div>
      <SectionHeader title="Libero professionista" subtitle="Conto separato dalla famiglia: qui entra tutto l'incasso delle fatture. Nulla passa automaticamente al conto familiare: solo un giroconto esplicito lo fa." />

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Regime forfettario</div>
        <div className="form-row" style={styles.formRow}>
          <Field label="Coefficiente di redditivita (%)">
            <input type="number" step="0.1" value={settings.coeffRedditivita} onChange={(e) => updateSettings({ coeffRedditivita: Number(e.target.value) })} style={{ width: 100 }} />
          </Field>
          <Field label="Aliquota imposta sostitutiva (%)">
            <input type="number" step="0.1" value={settings.aliquotaImposta} onChange={(e) => updateSettings({ aliquotaImposta: Number(e.target.value) })} style={{ width: 100 }} />
          </Field>
        </div>
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Regime ordinario</div>
        <div className="form-row" style={styles.formRow}>
          <Field label="Scaglione 1 fino a (EUR)">
            <input type="number" value={settings.scaglione1Fino} onChange={(e) => updateSettings({ scaglione1Fino: Number(e.target.value) })} style={{ width: 100 }} />
          </Field>
          <Field label="Aliquota IRPEF scaglione 1 (%)">
            <input type="number" step="0.1" value={settings.aliquota1} onChange={(e) => updateSettings({ aliquota1: Number(e.target.value) })} style={{ width: 90 }} />
          </Field>
          <Field label="Scaglione 2 fino a (EUR)">
            <input type="number" value={settings.scaglione2Fino} onChange={(e) => updateSettings({ scaglione2Fino: Number(e.target.value) })} style={{ width: 100 }} />
          </Field>
          <Field label="Aliquota IRPEF scaglione 2 (%)">
            <input type="number" step="0.1" value={settings.aliquota2} onChange={(e) => updateSettings({ aliquota2: Number(e.target.value) })} style={{ width: 90 }} />
          </Field>
          <Field label="Aliquota IRPEF oltre (%)">
            <input type="number" step="0.1" value={settings.aliquota3} onChange={(e) => updateSettings({ aliquota3: Number(e.target.value) })} style={{ width: 90 }} />
          </Field>
          <Field label="Aliquota IVA (%)">
            <input type="number" step="0.1" value={settings.aliquotaIva} onChange={(e) => updateSettings({ aliquotaIva: Number(e.target.value) })} style={{ width: 90 }} />
          </Field>
          <Field label="Aliquota ritenuta d'acconto (%)">
            <input type="number" step="0.1" value={settings.aliquotaRitenuta} onChange={(e) => updateSettings({ aliquotaRitenuta: Number(e.target.value) })} style={{ width: 90 }} />
          </Field>
        </div>
        <p style={styles.hintText}>
          Nel regime ordinario l'IRPEF e' progressiva e cumulativa con il reddito da lavoro dipendente dell'anno.
          L'imposta mostrata per ogni mese e' una stima ottenuta ripartendo in proporzione l'IRPEF marginale attribuibile all'attivita' professionale, gia' al netto della ritenuta d'acconto versata dal cliente.
        </p>
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Reddito da lavoro dipendente (per anno)</div>
        <p style={styles.hintText}>Serve a calcolare correttamente lo scaglione IRPEF applicabile al reddito professionale negli anni in regime ordinario. L'IRPEF e l'INPS su questo reddito sono gia' state trattenute e versate dal datore di lavoro: qui vengono solo stimate (in base agli scaglioni impostati) per tenerne conto nel calcolo, ma puoi correggerle a mano se il datore di lavoro ha fatto un conguaglio positivo o negativo in busta paga.</p>
        <div className="form-row" style={styles.formRow}>
          <Field label="Aliquota INPS dipendente stimata (%)">
            <input type="number" step="0.01" value={settings.aliquotaInpsDipendente} onChange={(e) => updateSettings({ aliquotaInpsDipendente: Number(e.target.value) })} style={{ width: 90 }} />
          </Field>
        </div>
        <div className="form-row" style={styles.formRow}>
          <Field label="Anno">
            <input type="number" value={rdAnno} onChange={(e) => setRdAnno(e.target.value)} style={{ width: 90 }} />
          </Field>
          <Field label="Reddito annuo lordo (EUR)">
            <input type="number" step="0.01" value={rdImporto} onChange={(e) => onRdImportoChange(e.target.value)} style={{ width: 130 }} />
          </Field>
          <Field label={`IRPEF gia' trattenuta (EUR)`}>
            <input type="number" step="0.01" value={rdIrpef} onChange={(e) => { setRdIrpefTouched(true); setRdIrpef(e.target.value); }} placeholder="0,00" style={{ width: 120 }} />
          </Field>
          <Field label={`INPS gia' trattenuta (EUR)`}>
            <input type="number" step="0.01" value={rdInps} onChange={(e) => { setRdInpsTouched(true); setRdInps(e.target.value); }} placeholder="0,00" style={{ width: 120 }} />
          </Field>
          <button style={styles.primaryBtn} onClick={submitRd}>
            {rdEditId ? <Check size={14} /> : <Plus size={14} />} {rdEditId ? "Salva" : "Aggiungi"}
          </button>
          {rdEditId && <button style={styles.ghostBtn} onClick={resetRdForm}><X size={14} /> Annulla</button>}
        </div>
        {redditoDipendente.length === 0 ? <EmptyState text="Nessun reddito da lavoro dipendente inserito." /> : (
          <table>
            <thead><tr><th>Anno</th><th className="num">Reddito lordo</th><th className="num">IRPEF trattenuta</th><th className="num">INPS trattenuta</th><th></th></tr></thead>
            <tbody>
              {[...redditoDipendente].sort((a, b) => String(a.anno).localeCompare(String(b.anno))).map((r) => {
                const y = yearlyOrdinario[String(r.anno)];
                const irpefMostrata = y ? y.irpefDipendente : calcIrpef(r.importo, settings);
                const inpsMostrata = y ? y.inpsDipendente : (Number(r.importo) * settings.aliquotaInpsDipendente) / 100;
                return (
                  <tr key={r.id}>
                    <td>{r.anno}</td>
                    <td className="num">{fmtEUR(r.importo)}</td>
                    <td className="num">{fmtEUR(irpefMostrata)}</td>
                    <td className="num">{fmtEUR(inpsMostrata)}</td>
                    <td><RowActions onEdit={() => startEditRd(r)} onDelete={() => redditoDipendenteApi.remove(r.id)} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      <div className="cards" style={styles.cardsGrid}>
        <MetricCard label="Incassato (totale fatture)" value={fmtEUR(totaleIncassato)} icon={PiggyBank} />
        <MetricCard label="Versato all'erario" value={fmtEUR(totalePrelevato)} icon={Receipt} />
        <MetricCard label="Spese professionali" value={fmtEUR(totaleSpeseLavorative)} icon={Briefcase} />
        <MetricCard label="Trasferito alla famiglia" value={fmtEUR(totaleGiroconti)} icon={TrendingDown} />
        <MetricCard label="Saldo conto libero professionista" value={fmtEUR(saldoReale)} icon={Landmark} tone={saldoReale >= 0 ? "green" : "brick"} />
        <MetricCard label="Di cui: fondo tasse ancora necessario" value={fmtEUR(fondoTasseNecessario)} icon={PiggyBank} tone={saldoReale >= fondoTasseNecessario ? "green" : "brick"} />
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Andamento conto libero professionista</div>
        <p style={styles.hintText}>Questo grafico e il saldo di questo conto non compaiono nel calendario del conto familiare. "Saldo reale" e' tutto l'incasso al netto di tasse pagate, spese professionali e giroconti; "Fondo tasse necessario" e' quanto di quel saldo, in teoria, non andrebbe toccato perche' destinato alle tasse. Se il saldo reale scende sotto il fondo tasse necessario, stai intaccando soldi delle tasse. Passa il mouse su un mese per vedere il dettaglio dei movimenti.</p>
        <div style={{ height: 220 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={businessChartData} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" />
              <XAxis dataKey="mese" tick={{ fontSize: 11, fill: "var(--text-muted)" }} />
              <YAxis tick={{ fontSize: 11, fill: "var(--text-muted)" }} width={44} tickFormatter={(v) => fmtK(v)} />
              <Tooltip content={<BusinessChartTooltip />} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="saldo" name="Saldo reale conto" stroke="#3C6E47" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="fondoTasse" name="Fondo tasse necessario" stroke="#B8862E" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Fatturato mensile</div>
        <div className="form-row" style={styles.formRow}>
          <Field label="Mese">
            <input type="month" value={form.mese} onChange={(e) => setForm({ ...form, mese: e.target.value })} />
          </Field>
          {!editId && (
            <Field label="Ripeti fino al mese (opzionale)">
              <input type="month" value={form.ripetiFino} onChange={(e) => setForm({ ...form, ripetiFino: e.target.value })} min={form.mese} />
            </Field>
          )}
          <Field label="Regime">
            <select value={form.regime} onChange={(e) => onRegimeChange(e.target.value)}>
              <option value="forfettario">Forfettario</option>
              <option value="ordinario">Ordinario</option>
            </select>
          </Field>
          <Field label="Importo fattura, compenso (EUR)">
            <input type="number" step="0.01" value={form.fatturato} onChange={(e) => onFatturatoChange(e.target.value)} placeholder="0,00" style={{ width: 130 }} />
          </Field>
          {form.regime === "ordinario" && (
            <>
              <Field label="Costi deducibili (EUR)">
                <input type="number" step="0.01" value={form.costi} onChange={(e) => setForm({ ...form, costi: e.target.value })} placeholder="0,00" style={{ width: 110 }} />
              </Field>
              <Field label={`IVA (EUR, ${settings.aliquotaIva}% proposta)`}>
                <input type="number" step="0.01" value={form.iva} onChange={(e) => { setIvaTouched(true); setForm({ ...form, iva: e.target.value }); }} placeholder="0,00" style={{ width: 110 }} />
              </Field>
              <Field label={`Ritenuta d'acconto (EUR, ${settings.aliquotaRitenuta}% proposta)`}>
                <input type="number" step="0.01" value={form.ritenuta} onChange={(e) => { setRitenutaTouched(true); setForm({ ...form, ritenuta: e.target.value }); }} placeholder="0,00" style={{ width: 110 }} />
              </Field>
            </>
          )}
          <button style={styles.primaryBtn} onClick={submit}>
            {editId ? <Check size={14} /> : <Plus size={14} />}
            {editId ? "Salva" : (form.ripetiFino && form.ripetiFino > form.mese ? `Aggiungi ${monthKeysInRange(form.mese, form.ripetiFino).length} mesi` : "Aggiungi")}
          </button>
          {editId && <button style={styles.ghostBtn} onClick={resetForm}><X size={14} /> Annulla</button>}
        </div>
        {!editId && form.ripetiFino && form.ripetiFino > form.mese && (
          <p style={styles.hintText}>Utile per clienti che ti fatturano "a corpo" con lo stesso importo ogni mese: crea una voce identica per ciascun mese da {fmtMonthLabel(form.mese)} a {fmtMonthLabel(form.ripetiFino)}, restano comunque modificabili singolarmente in tabella.</p>
        )}
        {form.regime === "ordinario" && Number(form.fatturato) > 0 && (
          <p style={styles.hintText}>
            Incasso netto stimato in banca: {fmtEUR((Number(form.fatturato) || 0) + (Number(form.iva) || 0) - (Number(form.ritenuta) || 0))}
            {" "}({fmtEUR(form.fatturato)} + IVA {fmtEUR(form.iva)} − ritenuta {fmtEUR(form.ritenuta)})
          </p>
        )}

        <YearFilter years={availableYears(freelance, (f) => f.mese.split("-")[0])} value={filtroAnnoFatturato} onChange={setFiltroAnnoFatturato} />
        {sorted.length === 0 ? <EmptyState text="Nessun fatturato inserito." /> : (
          <div style={{ overflowX: "auto" }}>
          <table>
            <thead>
              <tr>
                <th>Mese</th><th>Regime</th><th className="num">Importo</th><th className="num">IVA</th><th className="num">Ritenuta</th>
                <th className="num">Incasso netto</th><th className="num">Imponibile</th><th className="num">Imposta</th><th className="num">INPS</th>
                <th className="num">Accantonato</th><th></th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((f) => {
                const t = taxCalcEntry(f);
                return (
                  <tr key={f.id}>
                    <td>{fmtMonthLabel(f.mese)}</td>
                    <td style={{ color: "var(--text-muted)" }}>{f.regime === "ordinario" ? "Ordinario" : "Forfettario"}</td>
                    <td className="num">{fmtEUR(f.fatturato)}</td>
                    <td className="num">{t.iva ? fmtEUR(t.iva) : "-"}</td>
                    <td className="num">{t.ritenuta ? fmtEUR(t.ritenuta) : "-"}</td>
                    <td className="num">{fmtEUR(t.incassoNetto)}</td>
                    <td className="num">{fmtEUR(t.imponibile)}</td>
                    <td className="num">{fmtEUR(t.imposta)}</td>
                    <td className="num">{fmtEUR(t.inps)}</td>
                    <td className="num" style={{ fontWeight: 600 }}>{fmtEUR(t.accantonamento)}</td>
                    <td style={{ whiteSpace: "nowrap" }}>
                      <RowActions onEdit={() => startEdit(f)} onDelete={() => api.remove(f.id)} />
                    </td>
                  </tr>

                );
              })}
            </tbody>
          </table>
          </div>
        )}
      </div>

      {anniInps.length > 0 && (
        <div className="panel" style={styles.panel}>
          <div className="panel-title" style={styles.panelTitle}>Riepilogo INPS per anno</div>
          <table>
            <thead>
              <tr><th>Anno</th><th className="num">Reddito imponibile INPS</th><th className="num">INPS totale da versare</th></tr>
            </thead>
            <tbody>
              {anniInps.map((y) => {
                const a = yearlyInps[y];
                return (
                  <tr key={y}>
                    <td>{y}</td>
                    <td className="num">{fmtEUR(a.imponibile)}</td>
                    <td className="num" style={{ fontWeight: 600 }}>{fmtEUR(a.inps)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <p style={styles.hintText}>Somma dei contributi INPS calcolati mese per mese (forfettario e ordinario insieme). Non tiene conto di eventuali minimali contributivi fissi previsti da alcune casse.</p>
        </div>
      )}

      {anniOrdinario.length > 0 && (
        <div className="panel" style={styles.panel}>
          <div className="panel-title" style={styles.panelTitle}>Riepilogo IRPEF regime ordinario per anno</div>
          <div style={{ overflowX: "auto" }}>
          <table>
            <thead>
              <tr><th>Anno</th><th className="num">Reddito dipendente</th><th className="num">IRPEF gia' trattenuta dal datore</th><th className="num">Reddito professionale lordo</th><th className="num">Spese deducibili</th><th className="num">Reddito imponibile IRPEF (netto)</th><th className="num">IRPEF lorda professionale</th><th className="num">Ritenute gia' versate</th><th className="num">IRPEF residua da accantonare</th><th className="num">IVA incassata</th><th className="num">IVA detraibile su acquisti</th><th className="num">IVA netta da versare</th></tr>
            </thead>
            <tbody>
              {anniOrdinario.map((y) => {
                const a = yearlyOrdinario[y];
                const residua = Math.max(0, a.irpefProfessionale - a.ritenutaTotale);
                return (
                  <tr key={y}>
                    <td>{y}</td>
                    <td className="num">{fmtEUR(a.redditoDipendente)}</td>
                    <td className="num">{fmtEUR(a.irpefDipendente)}</td>
                    <td className="num">{fmtEUR(a.redditoProfessionale)}</td>
                    <td className="num">{fmtEUR(a.costoSpeseDeducibili)}</td>
                    <td className="num">{fmtEUR(a.redditoImponibileIrpefNetto)}</td>
                    <td className="num">{fmtEUR(a.irpefProfessionale)}</td>
                    <td className="num">{fmtEUR(a.ritenutaTotale)}</td>
                    <td className="num" style={{ fontWeight: 600 }}>{fmtEUR(residua)}</td>
                    <td className="num">{fmtEUR(a.ivaTotale)}</td>
                    <td className="num">{fmtEUR(a.ivaCreditoSpese)}</td>
                    <td className="num" style={{ fontWeight: 600 }}>{fmtEUR(a.ivaNetta)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          </div>
          <p style={styles.hintText}>
            I contributi INPS versati sono deducibili dal reddito imponibile IRPEF (art. 10 TUIR), cosi' come le spese professionali (secondo la % di deducibilita' impostata su ognuna): l'IRPEF si calcola sul "Reddito imponibile IRPEF (netto)".
            L'IVA da versare e' gia' al netto dell'IVA detraibile sugli acquisti professionali (secondo la % di detraibilita' impostata su ogni spesa).
            Se le ritenute versate superano l'IRPEF calcolata, il credito risultante non viene mostrato qui: verra' recuperato in dichiarazione dei redditi.
          </p>
        </div>
      )}

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Scadenzario fiscale</div>
        <p style={styles.hintText}>
          Calcola automaticamente saldo e acconti secondo il meccanismo classico italiano (metodo storico): l'acconto dell'anno N+1 si basa sul dovuto complessivo dell'anno N, indipendentemente da ritenute/incassi futuri ancora sconosciuti.
          Il saldo invece e' al netto di quanto hai gia' versato come acconto per quello stesso anno (i pagamenti registrati con tipologia corrispondente e scadenza in quell'anno).
          Aliquote e date cambiano spesso per decreto di anno in anno: verifica sempre i valori con il tuo commercialista prima di pagare.
        </p>
        <div className="form-row" style={styles.formRow}>
          <Field label="Acconto (% del dovuto anno precedente)">
            <input type="number" step="1" value={settings.aliquotaAcconto} onChange={(e) => updateSettings({ aliquotaAcconto: Number(e.target.value) })} style={{ width: 90 }} />
          </Field>
          <Field label="Quota 1° rata acconto (%)">
            <input type="number" step="1" value={settings.quotaPrimoAcconto} onChange={(e) => updateSettings({ quotaPrimoAcconto: Number(e.target.value) })} style={{ width: 90 }} />
          </Field>
          <Field label="Scadenza saldo + 1° acconto">
            <div style={{ display: "flex", gap: 6 }}>
              <input type="number" min="1" max="31" value={settings.scadenzaSaldoGiorno} onChange={(e) => updateSettings({ scadenzaSaldoGiorno: Number(e.target.value) })} style={{ width: 55 }} />
              <input type="number" min="1" max="12" value={settings.scadenzaSaldoMese} onChange={(e) => updateSettings({ scadenzaSaldoMese: Number(e.target.value) })} style={{ width: 55 }} />
            </div>
          </Field>
          <Field label="Scadenza 2° acconto">
            <div style={{ display: "flex", gap: 6 }}>
              <input type="number" min="1" max="31" value={settings.scadenzaSecondoAccontoGiorno} onChange={(e) => updateSettings({ scadenzaSecondoAccontoGiorno: Number(e.target.value) })} style={{ width: 55 }} />
              <input type="number" min="1" max="12" value={settings.scadenzaSecondoAccontoMese} onChange={(e) => updateSettings({ scadenzaSecondoAccontoMese: Number(e.target.value) })} style={{ width: 55 }} />
            </div>
          </Field>
          <Field label="Acconto IVA (% dovuto anno precedente)">
            <input type="number" step="1" value={settings.aliquotaAccontoIva} onChange={(e) => updateSettings({ aliquotaAccontoIva: Number(e.target.value) })} style={{ width: 90 }} />
          </Field>
          <Field label="Scadenza acconto IVA">
            <div style={{ display: "flex", gap: 6 }}>
              <input type="number" min="1" max="31" value={settings.scadenzaAccontoIvaGiorno} onChange={(e) => updateSettings({ scadenzaAccontoIvaGiorno: Number(e.target.value) })} style={{ width: 55 }} />
              <input type="number" min="1" max="12" value={settings.scadenzaAccontoIvaMese} onChange={(e) => updateSettings({ scadenzaAccontoIvaMese: Number(e.target.value) })} style={{ width: 55 }} />
            </div>
          </Field>
        </div>

        <div className="panel-title" style={styles.panelTitle}>Liquidazioni IVA trimestrali</div>
        <p style={styles.hintText}>Per chi versa l'IVA a trimestre (non a saldo/acconto annuale): calcolate sull'IVA realmente incassata e detratta in ciascun trimestre dell'anno stesso, non sull'anno precedente. Le prime tre includono di norma una maggiorazione per interessi, la quarta si versa di solito col saldo annuale (nell'anno successivo).</p>
        <div className="form-row" style={styles.formRow}>
          <Field label="Scadenza 1° trimestre">
            <div style={{ display: "flex", gap: 6 }}>
              <input type="number" min="1" max="31" value={settings.scadenzaIva1Giorno} onChange={(e) => updateSettings({ scadenzaIva1Giorno: Number(e.target.value) })} style={{ width: 55 }} />
              <input type="number" min="1" max="12" value={settings.scadenzaIva1Mese} onChange={(e) => updateSettings({ scadenzaIva1Mese: Number(e.target.value) })} style={{ width: 55 }} />
            </div>
          </Field>
          <Field label="Scadenza 2° trimestre">
            <div style={{ display: "flex", gap: 6 }}>
              <input type="number" min="1" max="31" value={settings.scadenzaIva2Giorno} onChange={(e) => updateSettings({ scadenzaIva2Giorno: Number(e.target.value) })} style={{ width: 55 }} />
              <input type="number" min="1" max="12" value={settings.scadenzaIva2Mese} onChange={(e) => updateSettings({ scadenzaIva2Mese: Number(e.target.value) })} style={{ width: 55 }} />
            </div>
          </Field>
          <Field label="Scadenza 3° trimestre">
            <div style={{ display: "flex", gap: 6 }}>
              <input type="number" min="1" max="31" value={settings.scadenzaIva3Giorno} onChange={(e) => updateSettings({ scadenzaIva3Giorno: Number(e.target.value) })} style={{ width: 55 }} />
              <input type="number" min="1" max="12" value={settings.scadenzaIva3Mese} onChange={(e) => updateSettings({ scadenzaIva3Mese: Number(e.target.value) })} style={{ width: 55 }} />
            </div>
          </Field>
          <Field label="Scadenza 4° trimestre (anno succ.)">
            <div style={{ display: "flex", gap: 6 }}>
              <input type="number" min="1" max="31" value={settings.scadenzaIva4Giorno} onChange={(e) => updateSettings({ scadenzaIva4Giorno: Number(e.target.value) })} style={{ width: 55 }} />
              <input type="number" min="1" max="12" value={settings.scadenzaIva4Mese} onChange={(e) => updateSettings({ scadenzaIva4Mese: Number(e.target.value) })} style={{ width: 55 }} />
            </div>
          </Field>
          <Field label="Maggiorazione interessi (%)">
            <input type="number" step="0.1" min="0" value={settings.ivaTrimestraleMaggiorazione} onChange={(e) => updateSettings({ ivaTrimestraleMaggiorazione: Number(e.target.value) })} style={{ width: 90 }} />
          </Field>
        </div>
        {scadenzeFiscali.length === 0 ? <EmptyState text="Inserisci del fatturato per vedere le scadenze calcolate." /> : (
          <table>
            <thead><tr><th>Scadenza</th><th>Tipologia</th><th>Descrizione</th><th className="num">Importo</th><th></th></tr></thead>
            <tbody>
              {scadenzeFiscali.map((r) => (
                <tr key={r.id}>
                  <td>{fmtDate(r.data)}</td>
                  <td style={{ color: "var(--text-muted)" }}>{r.tipologia}</td>
                  <td>{r.descrizione}</td>
                  <td className="num" style={{ fontWeight: 600 }}>{fmtEUR(r.importo)}</td>
                  <td style={{ whiteSpace: "nowrap" }}>
                    <button
                      style={styles.linkBtn}
                      onClick={() => {
                        setPData(dateKey(r.data));
                        setPImporto(String(Math.round(r.importo * 100) / 100));
                        setPTipologia(r.tipologia);
                        setPNota(r.descrizione);
                        setPPeriodicita("una_tantum");
                        setPDataFine("");
                        setPEditId(null);
                      }}
                    >
                      Usa questi dati ↓
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Pagamenti tasse (dal conto libero professionista)</div>
        <p style={styles.hintText}>Impattano solo sul conto libero professionista, non sul conto familiare. Usa "Una tantum" per un versamento singolo, oppure "Mensile"/"Annuale" per pagamenti ricorrenti.</p>
        <div className="form-row" style={styles.formRow}>
          <Field label={pPeriodicita === "una_tantum" ? "Data" : "Prima scadenza"}>
            <input type="date" value={pData} onChange={(e) => setPData(e.target.value)} />
          </Field>
          <Field label="Tipologia">
            <select value={pTipologia} onChange={(e) => setPTipologia(e.target.value)}>
              {TIPOLOGIE_TASSE.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Importo (EUR)">
            <input type="number" step="0.01" value={pImporto} onChange={(e) => setPImporto(e.target.value)} style={{ width: 120 }} />
          </Field>
          <Field label="Periodicita">
            <select value={pPeriodicita} onChange={(e) => setPPeriodicita(e.target.value)}>
              <option value="una_tantum">Una tantum</option>
              <option value="mensile">Mensile</option>
              <option value="annuale">Annuale</option>
            </select>
          </Field>
          {pPeriodicita !== "una_tantum" && (
            <Field label="Data fine (opzionale)">
              <input type="date" value={pDataFine} onChange={(e) => setPDataFine(e.target.value)} min={pData} />
            </Field>
          )}
          <Field label="Descrizione (opzionale)">
            <input type="text" value={pNota} onChange={(e) => setPNota(e.target.value)} placeholder="Saldo, acconto, fondo previdenza..." style={{ width: 200 }} />
          </Field>
          <button
            style={styles.primaryBtn}
            onClick={() => {
              if (!pData || !pImporto) return;
              const payload = { data: pData, importo: Number(pImporto), tipologia: pTipologia, nota: pNota, periodicita: pPeriodicita };
              payload.dataFine = pPeriodicita !== "una_tantum" && pDataFine ? pDataFine : "";
              if (pEditId) prelieviApi.update(pEditId, payload);
              else prelieviApi.add(payload);
              setPImporto(""); setPNota(""); setPTipologia("Irpef"); setPPeriodicita("una_tantum"); setPDataFine(""); setPEditId(null);
            }}
          >
            {pEditId ? <Check size={14} /> : <Plus size={14} />} {pEditId ? "Salva" : "Aggiungi"}
          </button>
          {pEditId && (
            <button style={styles.ghostBtn} onClick={() => { setPEditId(null); setPImporto(""); setPNota(""); setPTipologia("Irpef"); setPPeriodicita("una_tantum"); setPDataFine(""); setPData(dateKey(new Date())); }}>
              <X size={14} /> Annulla
            </button>
          )}
        </div>
        {pPeriodicita !== "una_tantum" && !pDataFine && (
          <p style={styles.hintText}>Senza data di fine, il pagamento si ripete indefinitamente. Impostala se in futuro l'importo cambia o il versamento termina.</p>
        )}
        <YearFilter years={availableYears(prelievi, (p) => p.data.split("-")[0])} value={filtroAnnoPagamenti} onChange={setFiltroAnnoPagamenti} />
        {(() => {
          const prelieviFiltrati = [...prelievi].filter((p) => !filtroAnnoPagamenti || p.data.startsWith(filtroAnnoPagamenti)).sort((a, b) => a.data.localeCompare(b.data));
          return prelieviFiltrati.length === 0 ? <EmptyState text={filtroAnnoPagamenti ? "Nessun pagamento in questo anno." : "Nessun pagamento registrato."} /> : (
          <table>
            <thead><tr><th>{"Data / scadenza"}</th><th>Tipologia</th><th>Descrizione</th><th>Periodicita</th><th>Fine</th><th className="num">Importo</th><th></th></tr></thead>
            <tbody>
              {prelieviFiltrati.map((p) => (
                <tr key={p.id}>
                  <td>{fmtDate(parseDate(p.data))}</td>
                  <td style={{ color: "var(--text-muted)" }}>{p.tipologia || "Altro"}</td>
                  <td>{p.nota || "-"}</td>
                  <td style={{ color: "var(--text-muted)" }}>{{ una_tantum: "Una tantum", mensile: "Mensile", annuale: "Annuale" }[p.periodicita || "una_tantum"]}</td>
                  <td style={{ color: "var(--text-muted)" }}>{p.dataFine ? fmtDate(parseDate(p.dataFine)) : "-"}</td>
                  <td className="num">{fmtEUR(p.importo)}</td>
                  <td>
                    <RowActions
                      onEdit={() => { setPEditId(p.id); setPData(p.data); setPImporto(String(p.importo)); setPTipologia(p.tipologia || "Irpef"); setPNota(p.nota || ""); setPPeriodicita(p.periodicita || "una_tantum"); setPDataFine(p.dataFine || ""); }}
                      onDelete={() => prelieviApi.remove(p.id)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          );
        })()}
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Spese professionali (dal conto libero professionista)</div>
        <p style={styles.hintText}>
          Spese lavorative come PC, attrezzatura, fondo previdenza, software: escono dal conto libero professionista (riducono il suo saldo) e non toccano il conto familiare. Usa "Mensile"/"Annuale" per spese ricorrenti come un fondo previdenza.
          Le percentuali di deduzione/detrazione riducono automaticamente il reddito imponibile IRPEF e l'IVA da versare (riepilogo IRPEF, scadenzario, liquidazioni trimestrali): valgono solo per il regime ordinario, il forfettario non deduce costi reali.
          Se paghi a rate, inserisci in "Valore totale fattura" l'importo intero: le percentuali verranno calcolate una sola volta su quel totale (alla data della fattura), mentre "Importo" resta il valore della singola rata che esce dal conto.
        </p>
        <div className="form-row" style={styles.formRow}>
          <Field label={sPeriodicita === "una_tantum" ? "Data" : "Prima scadenza"}>
            <input type="date" value={sData} onChange={(e) => setSData(e.target.value)} />
          </Field>
          <Field label="Categoria">
            <select value={sCategoria} onChange={(e) => setSCategoria(e.target.value)}>
              {CATEGORIE_SPESE_LAVORATIVE.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Importo (EUR, netto, rata se pagamento rateale)">
            <input type="number" step="0.01" value={sImporto} onChange={(e) => setSImporto(e.target.value)} style={{ width: 140 }} />
          </Field>
          <Field label="Valore totale fattura (opzionale, se a rate)">
            <input type="number" step="0.01" value={sValoreTotaleFattura} onChange={(e) => setSValoreTotaleFattura(e.target.value)} placeholder="Vuoto = usa Importo" style={{ width: 160 }} />
          </Field>
          <Field label="% deducibile dal reddito">
            <input type="number" min="0" max="100" step="1" value={sPercDeduzione} onChange={(e) => setSPercDeduzione(e.target.value)} style={{ width: 90 }} />
          </Field>
          <Field label="% IVA detraibile">
            <input type="number" min="0" max="100" step="1" value={sPercDetrazioneIva} onChange={(e) => setSPercDetrazioneIva(e.target.value)} style={{ width: 90 }} />
          </Field>
          <Field label="Periodicita">
            <select value={sPeriodicita} onChange={(e) => setSPeriodicita(e.target.value)}>
              <option value="una_tantum">Una tantum</option>
              <option value="mensile">Mensile</option>
              <option value="annuale">Annuale</option>
            </select>
          </Field>
          {sPeriodicita !== "una_tantum" && (
            <Field label="Data fine (opzionale)">
              <input type="date" value={sDataFine} onChange={(e) => setSDataFine(e.target.value)} min={sData} />
            </Field>
          )}
          <Field label="Descrizione (opzionale)">
            <input type="text" value={sNota} onChange={(e) => setSNota(e.target.value)} placeholder="Es. nuovo monitor" style={{ width: 200 }} />
          </Field>
          <button
            style={styles.primaryBtn}
            onClick={() => {
              if (!sData || !sImporto) return;
              const payload = {
                data: sData, importo: Number(sImporto), categoria: sCategoria, nota: sNota, periodicita: sPeriodicita,
                percDeduzione: sPercDeduzione !== "" ? Number(sPercDeduzione) : 100,
                percDetrazioneIva: sPercDetrazioneIva !== "" ? Number(sPercDetrazioneIva) : 100,
                valoreTotaleFattura: sValoreTotaleFattura !== "" ? Number(sValoreTotaleFattura) : "",
              };
              payload.dataFine = sPeriodicita !== "una_tantum" && sDataFine ? sDataFine : "";
              if (sEditId) speseLavorativeApi.update(sEditId, payload);
              else speseLavorativeApi.add(payload);
              setSImporto(""); setSNota(""); setSCategoria("PC/Attrezzatura"); setSPeriodicita("una_tantum"); setSDataFine(""); setSPercDeduzione("100"); setSPercDetrazioneIva("100"); setSValoreTotaleFattura(""); setSEditId(null);
            }}
          >
            {sEditId ? <Check size={14} /> : <Plus size={14} />} {sEditId ? "Salva" : "Aggiungi"}
          </button>
          {sEditId && (
            <button style={styles.ghostBtn} onClick={() => { setSEditId(null); setSImporto(""); setSNota(""); setSCategoria("PC/Attrezzatura"); setSPeriodicita("una_tantum"); setSDataFine(""); setSPercDeduzione("100"); setSPercDetrazioneIva("100"); setSValoreTotaleFattura(""); setSData(dateKey(new Date())); }}>
              <X size={14} /> Annulla
            </button>
          )}
        </div>
        {sPeriodicita !== "una_tantum" && !sDataFine && (
          <p style={styles.hintText}>Senza data di fine, la spesa si ripete indefinitamente. Impostala se in futuro l'importo cambia o la spesa termina.</p>
        )}
        <YearFilter years={availableYears(speseLavorative, (s) => s.data.split("-")[0])} value={filtroAnnoSpese} onChange={setFiltroAnnoSpese} />
        {(() => {
          const speseFiltrate = [...speseLavorative].filter((s) => !filtroAnnoSpese || s.data.startsWith(filtroAnnoSpese)).sort((a, b) => a.data.localeCompare(b.data));
          return speseFiltrate.length === 0 ? <EmptyState text={filtroAnnoSpese ? "Nessuna spesa in questo anno." : "Nessuna spesa professionale registrata."} /> : (
          <div style={{ overflowX: "auto" }}>
          <table>
            <thead><tr><th>{"Data / scadenza"}</th><th>Categoria</th><th>Descrizione</th><th>Periodicita</th><th>Fine</th><th className="num">Importo</th><th className="num">Tot. fattura</th><th className="num">% reddito</th><th className="num">% IVA</th><th></th></tr></thead>
            <tbody>
              {speseFiltrate.map((s) => (
                <tr key={s.id}>
                  <td>{fmtDate(parseDate(s.data))}</td>
                  <td style={{ color: "var(--text-muted)" }}>{s.categoria || "Altro"}</td>
                  <td>{s.nota || "-"}</td>
                  <td style={{ color: "var(--text-muted)" }}>{{ una_tantum: "Una tantum", mensile: "Mensile", annuale: "Annuale" }[s.periodicita || "una_tantum"]}</td>
                  <td style={{ color: "var(--text-muted)" }}>{s.dataFine ? fmtDate(parseDate(s.dataFine)) : "-"}</td>
                  <td className="num">{fmtEUR(s.importo)}</td>
                  <td className="num" style={{ color: "var(--text-muted)" }}>{s.valoreTotaleFattura !== undefined && s.valoreTotaleFattura !== "" ? fmtEUR(s.valoreTotaleFattura) : "-"}</td>
                  <td className="num">{s.percDeduzione !== undefined && s.percDeduzione !== "" ? s.percDeduzione : 100}%</td>
                  <td className="num">{s.percDetrazioneIva !== undefined && s.percDetrazioneIva !== "" ? s.percDetrazioneIva : 100}%</td>
                  <td>
                    <RowActions
                      onEdit={() => { setSEditId(s.id); setSData(s.data); setSImporto(String(s.importo)); setSCategoria(s.categoria || "PC/Attrezzatura"); setSNota(s.nota || ""); setSPeriodicita(s.periodicita || "una_tantum"); setSDataFine(s.dataFine || ""); setSPercDeduzione(s.percDeduzione !== undefined && s.percDeduzione !== "" ? String(s.percDeduzione) : "100"); setSPercDetrazioneIva(s.percDetrazioneIva !== undefined && s.percDetrazioneIva !== "" ? String(s.percDetrazioneIva) : "100"); setSValoreTotaleFattura(s.valoreTotaleFattura !== undefined && s.valoreTotaleFattura !== "" ? String(s.valoreTotaleFattura) : ""); }}
                      onDelete={() => speseLavorativeApi.remove(s.id)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
          );
        })()}
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Giroconto verso il conto familiare</div>
        <p style={styles.hintText}>Sposta denaro dal conto libero professionista al conto familiare: riduce il saldo di questo conto e compare come entrata nel calendario del conto familiare.</p>
        <div className="form-row" style={styles.formRow}>
          <Field label="Data">
            <input type="date" value={gData} onChange={(e) => setGData(e.target.value)} />
          </Field>
          <Field label="Importo (EUR)">
            <input type="number" step="0.01" value={gImporto} onChange={(e) => setGImporto(e.target.value)} style={{ width: 120 }} />
          </Field>
          {!gEditId && (
            <Field label="Ripeti fino al mese (opzionale)">
              <input type="month" value={gRipetiFino} onChange={(e) => setGRipetiFino(e.target.value)} min={fmtMonthKey(parseDate(gData))} />
            </Field>
          )}
          <Field label="Nota (opzionale)">
            <input type="text" value={gNota} onChange={(e) => setGNota(e.target.value)} placeholder="Es. anticipo spese famiglia" style={{ width: 220 }} />
          </Field>
          <button
            style={styles.primaryBtn}
            onClick={() => {
              if (!gData || !gImporto) return;
              const payload = { importo: Number(gImporto), nota: gNota };
              if (gEditId) {
                giroconoApi.update(gEditId, { ...payload, data: gData });
              } else if (gRipetiFino && gRipetiFino > fmtMonthKey(parseDate(gData))) {
                const giorno = parseDate(gData).getDate();
                monthKeysInRange(fmtMonthKey(parseDate(gData)), gRipetiFino).forEach((mese) => {
                  giroconoApi.add({ ...payload, data: dateKey(monthKeyToDate(mese, giorno)) });
                });
              } else {
                giroconoApi.add({ ...payload, data: gData });
              }
              setGImporto(""); setGNota(""); setGRipetiFino(""); setGEditId(null);
            }}
          >
            {gEditId ? <Check size={14} /> : <Plus size={14} />}
            {gEditId ? "Salva" : (gRipetiFino && gRipetiFino > fmtMonthKey(parseDate(gData)) ? `Aggiungi ${monthKeysInRange(fmtMonthKey(parseDate(gData)), gRipetiFino).length} mesi` : "Aggiungi")}
          </button>
          {gEditId && (
            <button style={styles.ghostBtn} onClick={() => { setGEditId(null); setGImporto(""); setGNota(""); setGRipetiFino(""); setGData(dateKey(new Date())); }}>
              <X size={14} /> Annulla
            </button>
          )}
        </div>
        {!gEditId && gRipetiFino && gRipetiFino > fmtMonthKey(parseDate(gData)) && (
          <p style={styles.hintText}>Crea un giroconto identico lo stesso giorno del mese, da {fmtMonthLabel(fmtMonthKey(parseDate(gData)))} a {fmtMonthLabel(gRipetiFino)}: restano comunque modificabili singolarmente in tabella.</p>
        )}
        <YearFilter years={availableYears(giroconti, (g) => g.data.split("-")[0])} value={filtroAnnoGiroconti} onChange={setFiltroAnnoGiroconti} />
        {(() => {
          const giroFiltrati = [...giroconti].filter((g) => !filtroAnnoGiroconti || g.data.startsWith(filtroAnnoGiroconti)).sort((a, b) => a.data.localeCompare(b.data));
          return giroFiltrati.length === 0 ? <EmptyState text={filtroAnnoGiroconti ? "Nessun giroconto in questo anno." : "Nessun giroconto registrato."} /> : (
          <table>
            <thead><tr><th>Data</th><th>Nota</th><th className="num">Importo</th><th></th></tr></thead>
            <tbody>
              {giroFiltrati.map((g) => (
                <tr key={g.id}>
                  <td>{fmtDate(parseDate(g.data))}</td>
                  <td>{g.nota || "-"}</td>
                  <td className="num">{fmtEUR(g.importo)}</td>
                  <td>
                    <RowActions
                      onEdit={() => { setGEditId(g.id); setGData(g.data); setGImporto(String(g.importo)); setGNota(g.nota || ""); setGRipetiFino(""); }}
                      onDelete={() => giroconoApi.remove(g.id)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          );
        })()}
      </div>
    </div>
  );
}

function SpouseTab({ spouse, api, settings, updateSettings }) {
  const [mese, setMese] = useState(fmtMonthKey(new Date()));
  const [netto, setNetto] = useState("");
  const [editId, setEditId] = useState(null);
  const [filtroAnno, setFiltroAnno] = useState("");
  const sorted = [...spouse].filter((s) => !filtroAnno || s.mese.startsWith(filtroAnno)).sort((a, b) => a.mese.localeCompare(b.mese));

  const submit = () => {
    if (!mese || !netto) return;
    if (editId) { api.update(editId, { mese, netto: Number(netto) }); setEditId(null); }
    else api.add({ mese, netto: Number(netto) });
    setNetto("");
  };

  return (
    <div>
      <SectionHeader title="Entrate di tua moglie" subtitle="Importi netti mensili." />
      <div className="panel" style={styles.panel}>
        <div className="form-row" style={styles.formRow}>
          <Field label="Giorno accredito mensile">
            <input type="number" min="1" max="28" value={settings.giornoStipendioMoglie} onChange={(e) => updateSettings({ giornoStipendioMoglie: Number(e.target.value) })} style={{ width: 80 }} />
          </Field>
        </div>
        <div className="form-row" style={styles.formRow}>
          <Field label="Mese">
            <input type="month" value={mese} onChange={(e) => setMese(e.target.value)} />
          </Field>
          <Field label="Netto (EUR)">
            <input type="number" step="0.01" value={netto} onChange={(e) => setNetto(e.target.value)} placeholder="0,00" style={{ width: 120 }} />
          </Field>
          <button style={styles.primaryBtn} onClick={submit}>
            {editId ? <Check size={14} /> : <Plus size={14} />} {editId ? "Salva" : "Aggiungi"}
          </button>
          {editId && <button style={styles.ghostBtn} onClick={() => { setEditId(null); setNetto(""); }}><X size={14} /> Annulla</button>}
        </div>
        <YearFilter years={availableYears(spouse, (s) => s.mese.split("-")[0])} value={filtroAnno} onChange={setFiltroAnno} />
        {sorted.length === 0 ? <EmptyState text={filtroAnno ? "Nessuna entrata in questo anno." : "Nessuna entrata inserita."} /> : (
          <table>
            <thead><tr><th>Mese</th><th className="num">Netto</th><th></th></tr></thead>
            <tbody>
              {sorted.map((s) => (
                <tr key={s.id}>
                  <td>{fmtMonthLabel(s.mese)}</td>
                  <td className="num">{fmtEUR(s.netto)}</td>
                  <td><RowActions onEdit={() => { setEditId(s.id); setMese(s.mese); setNetto(String(s.netto)); }} onDelete={() => api.remove(s.id)} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function RecurringTab({ title, hint, items, api, sign, withCategory }) {
  const blank = { descrizione: "", importo: "", periodicita: "una_tantum", data: dateKey(new Date()), dataFine: "", categoria: EXPENSE_CATEGORIES[0] };
  const [form, setForm] = useState(blank);
  const [editId, setEditId] = useState(null);
  const [filtroAnno, setFiltroAnno] = useState("");

  const submit = () => {
    if (!form.descrizione || !form.importo || !form.data) return;
    const payload = { descrizione: form.descrizione, importo: Number(form.importo), periodicita: form.periodicita, data: form.data };
    payload.dataFine = form.periodicita !== "una_tantum" && form.dataFine ? form.dataFine : "";
    if (withCategory) payload.categoria = form.categoria;
    if (editId) { api.update(editId, payload); setEditId(null); }
    else api.add(payload);
    setForm(blank);
  };

  const sorted = [...items].filter((it) => !filtroAnno || it.data.startsWith(filtroAnno)).sort((a, b) => a.data.localeCompare(b.data));
  const periodLabel = { una_tantum: "Una tantum", mensile: "Mensile", annuale: "Annuale" };

  return (
    <div>
      <SectionHeader title={title} subtitle={hint} />
      <div className="panel" style={styles.panel}>
        <div className="form-row" style={styles.formRow}>
          <Field label="Descrizione">
            <input type="text" value={form.descrizione} onChange={(e) => setForm({ ...form, descrizione: e.target.value })} placeholder={sign === "entrata" ? "Assegno familiare" : "Bolletta luce"} style={{ width: 200 }} />
          </Field>
          {withCategory && (
            <Field label="Tipologia">
              <select value={form.categoria} onChange={(e) => setForm({ ...form, categoria: e.target.value })}>
                {EXPENSE_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </Field>
          )}
          <Field label="Importo (EUR)">
            <input type="number" step="0.01" value={form.importo} onChange={(e) => setForm({ ...form, importo: e.target.value })} style={{ width: 110 }} />
          </Field>
          <Field label="Periodicita">
            <select value={form.periodicita} onChange={(e) => setForm({ ...form, periodicita: e.target.value })}>
              <option value="una_tantum">Una tantum</option>
              <option value="mensile">Mensile</option>
              <option value="annuale">Annuale</option>
            </select>
          </Field>
          <Field label={form.periodicita === "una_tantum" ? "Data" : "Prima scadenza"}>
            <input type="date" value={form.data} onChange={(e) => setForm({ ...form, data: e.target.value })} />
          </Field>
          {form.periodicita !== "una_tantum" && (
            <Field label="Data fine (opzionale)">
              <input type="date" value={form.dataFine} onChange={(e) => setForm({ ...form, dataFine: e.target.value })} min={form.data} />
            </Field>
          )}
          <button style={styles.primaryBtn} onClick={submit}>
            {editId ? <Check size={14} /> : <Plus size={14} />} {editId ? "Salva" : "Aggiungi"}
          </button>
          {editId && <button style={styles.ghostBtn} onClick={() => { setEditId(null); setForm(blank); }}><X size={14} /> Annulla</button>}
        </div>
        {form.periodicita !== "una_tantum" && !form.dataFine && (
          <p style={styles.hintText}>Senza data di fine, la voce si ripete indefinitamente. Impostala se in futuro l'importo cambia o la voce termina.</p>
        )}

        <YearFilter years={availableYears(items, (it) => it.data.split("-")[0])} value={filtroAnno} onChange={setFiltroAnno} />
        {sorted.length === 0 ? <EmptyState text={filtroAnno ? "Nessuna voce in questo anno." : "Nessuna voce inserita."} /> : (
          <table>
            <thead>
              <tr>
                <th>Descrizione</th>
                {withCategory && <th>Tipologia</th>}
                <th className="num">Importo</th>
                <th>Periodicita</th>
                <th>{sign === "entrata" ? "Data" : "Scadenza"}</th>
                <th>Fine</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((it) => (
                <tr key={it.id}>
                  <td>{it.descrizione}</td>
                  {withCategory && <td style={{ color: "var(--text-muted)" }}>{it.categoria}</td>}
                  <td className="num" style={{ color: sign === "entrata" ? "var(--green)" : "var(--brick)" }}>{fmtEUR(sign === "entrata" ? it.importo : -it.importo)}</td>
                  <td>{periodLabel[it.periodicita]}</td>
                  <td>{fmtDate(parseDate(it.data))}</td>
                  <td style={{ color: "var(--text-muted)" }}>{it.dataFine ? fmtDate(parseDate(it.dataFine)) : "-"}</td>
                  <td>
                    <RowActions
                      onEdit={() => { setEditId(it.id); setForm({ descrizione: it.descrizione, importo: String(it.importo), periodicita: it.periodicita, data: it.data, dataFine: it.dataFine || "", categoria: it.categoria || EXPENSE_CATEGORIES[0] }); }}
                      onDelete={() => api.remove(it.id)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function ForecastTab({ settings, updateSettings, saldoAllaData, saldoContoAlla, fondoTasseAlla }) {
  const orizzonteMesi = Math.max(1, Math.round(settings.previsioneOrizzonteAnni * 12));
  const oggi = startOfMonth(new Date());

  // Considerare il conto libero professionista nella previsione e' un'eccezione
  // esplicita: ovunque altrove nell'app conto famiglia e conto libero
  // professionista restano separati, ma qui (solo qui) puo' avere senso
  // "incrociarli" per decidere quanto sia davvero prudente investire.
  const [considerareLavorativo, setConsiderareLavorativo] = useState(true);

  // Saldo familiare proiettato mese per mese, dal mese corrente fino
  // all'orizzonte impostato, usando le stesse regole ricorrenti (entrate
  // fisse, extra, uscite, giroconti) gia' presenti nel calendario.
  // In parallelo calcoliamo anche la differenza tra il saldo reale del conto
  // libero professionista e quanto gli servirebbe per le tasse: se positiva
  // e' un surplus potenzialmente disponibile, se negativa e' un buco che la
  // famiglia dovrebbe idealmente coprire. Il "saldo combinato" la somma
  // (quindi la sottrae automaticamente quando e' negativa) al saldo familiare.
  const proiezione = useMemo(() => {
    const out = [];
    for (let i = 0; i <= orizzonteMesi; i++) {
      const m = addMonths(oggi, i);
      const data = endOfMonth(m);
      const saldoFamiliare = saldoAllaData(data);
      const differenzaLavorativo = saldoContoAlla(data) - fondoTasseAlla(data);
      out.push({
        indice: i,
        data,
        label: `${MONTH_NAMES[m.getMonth()].slice(0, 3)} ${String(m.getFullYear()).slice(2)}`,
        saldoFamiliare,
        differenzaLavorativo,
        saldoCombinato: saldoFamiliare + differenzaLavorativo,
      });
    }
    return out.map((p) => ({ ...p, saldo: considerareLavorativo ? p.saldoCombinato : p.saldoFamiliare }));
  }, [orizzonteMesi, oggi, saldoAllaData, saldoContoAlla, fondoTasseAlla, considerareLavorativo]);

  // Se il surplus/deficit lavorativo resta sempre positivo per tutto
  // l'orizzonte, e' un margine che si puo' considerare in modo affidabile
  // per decidere di investirlo; se anche un solo mese va sotto zero, va
  // trattato con piu' cautela (in quel mese la famiglia ne risente).
  const differenzaSemprePositiva = proiezione.every((p) => p.differenzaLavorativo >= 0);
  const differenzaMinima = proiezione.reduce((min, p) => Math.min(min, p.differenzaLavorativo), Infinity);
  const differenzaOggi = proiezione.length ? proiezione[0].differenzaLavorativo : 0;

  const chartData = useMemo(() => proiezione.map((p) => ({
    mese: p.label,
    saldoFamiliare: Math.round(p.saldoFamiliare),
    saldoCombinato: Math.round(p.saldoCombinato),
  })), [proiezione]);

  // Periodi in cui il saldo non aumenta per almeno N mesi consecutivi
  // (stagnazione o discesa): raggruppa i tratti massimali non crescenti.
  const periodiStagnazione = useMemo(() => {
    const runs = [];
    let i = 0;
    while (i < proiezione.length) {
      let j = i;
      while (j + 1 < proiezione.length && proiezione[j + 1].saldo <= proiezione[j].saldo) j++;
      const lunghezzaMesi = j - i + 1;
      if (lunghezzaMesi >= settings.previsioneMesiStagnazione && j > i) {
        runs.push({ inizio: proiezione[i], fine: proiezione[j], mesi: lunghezzaMesi });
      }
      i = j + 1;
    }
    return runs;
  }, [proiezione, settings.previsioneMesiStagnazione]);

  // Periodi in cui il saldo scende sotto la soglia critica impostata.
  const periodiSottoSoglia = useMemo(() => {
    const runs = [];
    let i = 0;
    while (i < proiezione.length) {
      if (proiezione[i].saldo < settings.previsioneSogliaCritica) {
        let j = i;
        while (j + 1 < proiezione.length && proiezione[j + 1].saldo < settings.previsioneSogliaCritica) j++;
        runs.push({ inizio: proiezione[i], fine: proiezione[j] });
        i = j + 1;
      } else {
        i++;
      }
    }
    return runs;
  }, [proiezione, settings.previsioneSogliaCritica]);

  // Saldo minimo proiettato "a bocce ferme" (senza alcun investimento): serve
  // sia come indicatore generale, sia come base per la modalita' "una tantum".
  const { saldoMinimo, meseSaldoMinimo } = useMemo(() => {
    let min = Infinity;
    let meseMin = proiezione[0];
    proiezione.forEach((p) => {
      if (p.saldo < min) { min = p.saldo; meseMin = p; }
    });
    return { saldoMinimo: min, meseSaldoMinimo: meseMin };
  }, [proiezione]);

  // Modalita' di investimento: cambia come l'importo A riduce il saldo nel
  // tempo, quindi cambia anche il calcolo del massimo A sostenibile.
  // - Una tantum: prelievo unico oggi, riduce il saldo di A per sempre da qui in poi.
  //   Vincolo al mese i: saldo[i] - A >= soglia  =>  A <= saldo[i] - soglia per ogni i.
  // - Mensile (senza fine): un'uscita ricorrente di A al mese, la riduzione
  //   cumulata al mese i (indice da 0) e' A*(i+1) perche' si accumula mese dopo mese.
  //   Vincolo: A <= (saldo[i] - soglia) / (i+1) per ogni i.
  // - Mensile per M mesi: come sopra ma la riduzione cumulata si ferma a A*M
  //   una volta passati M mesi (l'importo gia' investito resta investito,
  //   semplicemente non ne aggiungi altro): riduzione al mese i = A*min(i+1, M).
  //   Vincolo: A <= (saldo[i] - soglia) / min(i+1, M) per ogni i.
  // In tutti i casi il massimo A sostenibile e' il minimo, su tutti i mesi
  // proiettati, del rapporto tra margine disponibile e divisore del mese.
  // L'investimento puo' anche partire non da oggi ma da un mese scelto piu'
  // avanti: utile se il punto critico e' proprio adesso (es. un buco
  // temporaneo nel conto libero professionista) ma la situazione migliora
  // presto - i mesi PRIMA dell'inizio scelto non vengono vincolati, perche'
  // non hai ancora prelevato nulla in quel periodo.
  const [modalitaInvestimento, setModalitaInvestimento] = useState("una_tantum");
  const [durataMesiInvestimento, setDurataMesiInvestimento] = useState(12);
  const [meseInizioIdx, setMeseInizioIdx] = useState(0);

  const investimento = useMemo(() => {
    const soglia = settings.previsioneSogliaCritica;
    const durata = Math.max(1, Math.round(durataMesiInvestimento) || 1);
    const inizio = Math.min(Math.max(0, meseInizioIdx), Math.max(0, proiezione.length - 1));
    let best = Infinity;
    let meseCritico = proiezione[inizio] || proiezione[0];
    for (let i = inizio; i < proiezione.length; i++) {
      const p = proiezione[i];
      let divisore = 1; // una tantum: riduzione fissa fin dall'inizio scelto
      if (modalitaInvestimento === "mensile") divisore = i - inizio + 1; // si accumula ogni mese, senza fine
      else if (modalitaInvestimento === "mensile_limitato") divisore = Math.min(i - inizio + 1, durata); // si accumula solo per i primi "durata" mesi
      const valore = (p.saldo - soglia) / divisore;
      if (valore < best) { best = valore; meseCritico = p; }
    }
    return { importo: Math.max(0, best), meseCritico };
  }, [proiezione, modalitaInvestimento, durataMesiInvestimento, meseInizioIdx, settings.previsioneSogliaCritica]);

  const formatPeriodo = (run) => run.inizio.indice === run.fine.indice
    ? run.inizio.label
    : `${run.inizio.label} \u2013 ${run.fine.label}`;

  return (
    <div>
      <SectionHeader
        title="Previsioni"
        subtitle="Proiezione del saldo del conto familiare in base alle regole ricorrenti gia' impostate (entrate fisse, entrate extra, uscite, giroconti). Non tiene conto di fatturato futuro non ancora inserito ne' di eventi imprevisti."
      />

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Parametri della previsione</div>
        <div className="form-row" style={styles.formRow}>
          <Field label="Mesi di stagnazione (N)">
            <input type="number" min="2" value={settings.previsioneMesiStagnazione} onChange={(e) => updateSettings({ previsioneMesiStagnazione: Math.max(2, Number(e.target.value)) })} style={{ width: 90 }} />
          </Field>
          <Field label="Soglia critica (EUR)">
            <input type="number" step="50" value={settings.previsioneSogliaCritica} onChange={(e) => updateSettings({ previsioneSogliaCritica: Number(e.target.value) })} style={{ width: 110 }} />
          </Field>
          <Field label="Orizzonte (anni)">
            <input type="number" min="1" max="20" value={settings.previsioneOrizzonteAnni} onChange={(e) => updateSettings({ previsioneOrizzonteAnni: Math.max(1, Number(e.target.value)) })} style={{ width: 90 }} />
          </Field>
        </div>
        <p style={styles.hintText}>
          "Stagnazione" = il saldo non aumenta (resta uguale o scende) per almeno N mesi consecutivi. "Soglia critica" = livello minimo di saldo sotto il quale consideri la situazione a rischio.
        </p>
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Conto libero professionista nella previsione</div>
        <p style={styles.hintText}>
          Eccezione voluta solo qui: altrove nell'app il conto familiare e il conto libero professionista restano sempre separati. In questa sezione puoi invece "incrociarli" per capire quanto sia prudente investire: la differenza tra il saldo reale del conto libero professionista e quanto gli servirebbe per le tasse (un surplus, se positiva; un buco da coprire, se negativa) viene sommata al saldo familiare mese per mese.
        </p>
        <label style={styles.checkRow}>
          <input type="checkbox" checked={considerareLavorativo} onChange={(e) => setConsiderareLavorativo(e.target.checked)} />
          <span>Considera anche il surplus/deficit del conto libero professionista nella previsione e nel calcolo dell'investimento</span>
        </label>
        <div className="cards" style={styles.cardsGrid}>
          <MetricCard label="Surplus/deficit lavorativo oggi" value={fmtEUR(differenzaOggi)} icon={Briefcase} tone={differenzaOggi >= 0 ? "green" : "brick"} />
          <MetricCard label="Minimo nell'orizzonte" value={fmtEUR(differenzaMinima)} icon={Compass} tone={differenzaMinima >= 0 ? "green" : "brick"} />
          <MetricCard label="Sempre positivo nell'orizzonte?" value={differenzaSemprePositiva ? "Si'" : "No"} icon={AlertTriangle} tone={differenzaSemprePositiva ? "green" : "brick"} />
        </div>
        {!differenzaSemprePositiva && (
          <p style={styles.hintText}>Attenzione: in almeno un mese dell'orizzonte il conto libero professionista risulterebbe sotto quanto necessario per le tasse. Se hai attivato la casella sopra, questo si riflette come una riduzione del saldo familiare combinato in quel periodo.</p>
        )}
      </div>

      <div className="cards" style={styles.cardsGrid}>
        <MetricCard label="Saldo minimo proiettato" value={fmtEUR(saldoMinimo)} icon={Wallet} tone={saldoMinimo >= settings.previsioneSogliaCritica ? "green" : "brick"} />
        <MetricCard label="Quando si verifica" value={meseSaldoMinimo ? meseSaldoMinimo.label : "-"} icon={CalendarDays} />
        <MetricCard
          label={modalitaInvestimento === "una_tantum" ? "Investimento una tantum" : "Investimento mensile"}
          value={fmtEUR(investimento.importo) + (modalitaInvestimento === "una_tantum" ? "" : "/mese")}
          icon={PiggyBank}
          tone={investimento.importo > 0 ? "green" : "brick"}
        />
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Andamento saldo proiettato ({settings.previsioneOrizzonteAnni} {settings.previsioneOrizzonteAnni === 1 ? "anno" : "anni"})</div>
        <p style={styles.hintText}>La linea usata per le fasi critiche e l'investimento (in base alla casella sopra) e' evidenziata; l'altra e' mostrata piu' tenue solo per confronto.</p>
        <div style={{ height: 260 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" />
              <XAxis dataKey="mese" tick={{ fontSize: 10, fill: "var(--text-muted)" }} interval={Math.max(0, Math.floor(chartData.length / 12))} />
              <YAxis tick={{ fontSize: 11, fill: "var(--text-muted)" }} width={44} tickFormatter={(v) => fmtK(v)} />
              <Tooltip formatter={(v) => fmtEUR(v)} contentStyle={{ fontSize: 12, fontFamily: "var(--font-body)" }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <ReferenceLine y={settings.previsioneSogliaCritica} stroke="var(--brick)" strokeDasharray="4 4" label={{ value: "Soglia critica", position: "insideTopRight", fontSize: 10, fill: "var(--brick)" }} />
              <Line type="monotone" dataKey="saldoFamiliare" name="Saldo solo familiare" stroke={considerareLavorativo ? "var(--line)" : "#3C6E47"} strokeWidth={considerareLavorativo ? 1.5 : 2} dot={false} />
              <Line type="monotone" dataKey="saldoCombinato" name="Saldo familiare + lavorativo" stroke={considerareLavorativo ? "#3C6E47" : "var(--line)"} strokeWidth={considerareLavorativo ? 2 : 1.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Fasi critiche individuate</div>
        {periodiStagnazione.length === 0 && periodiSottoSoglia.length === 0 ? (
          <EmptyState text="Nessuna fase critica individuata nell'orizzonte impostato: il saldo cresce regolarmente e non scende mai sotto la soglia." />
        ) : (
          <>
            {periodiSottoSoglia.length > 0 && (
              <div style={{ marginBottom: 14 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8, color: "var(--brick)", fontWeight: 600, fontSize: 13 }}>
                  <AlertTriangle size={15} /> Saldo sotto la soglia critica ({fmtEUR(settings.previsioneSogliaCritica)})
                </div>
                <table>
                  <thead><tr><th>Periodo</th><th className="num">Saldo minimo nel periodo</th></tr></thead>
                  <tbody>
                    {periodiSottoSoglia.map((r, i) => {
                      let min = Infinity;
                      for (let idx = r.inizio.indice; idx <= r.fine.indice; idx++) min = Math.min(min, proiezione[idx].saldo);
                      return (
                        <tr key={i}>
                          <td>{formatPeriodo(r)}</td>
                          <td className="num" style={{ color: "var(--brick)", fontWeight: 600 }}>{fmtEUR(min)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
            {periodiStagnazione.length > 0 && (
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8, color: "var(--gold)", fontWeight: 600, fontSize: 13 }}>
                  <AlertTriangle size={15} /> Saldo che non aumenta per almeno {settings.previsioneMesiStagnazione} mesi
                </div>
                <table>
                  <thead><tr><th>Periodo</th><th className="num">Durata</th><th className="num">Da</th><th className="num">A</th></tr></thead>
                  <tbody>
                    {periodiStagnazione.map((r, i) => (
                      <tr key={i}>
                        <td>{formatPeriodo(r)}</td>
                        <td className="num">{r.mesi} mesi</td>
                        <td className="num">{fmtEUR(r.inizio.saldo)}</td>
                        <td className="num">{fmtEUR(r.fine.saldo)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Investimento possibile</div>

        <div className="form-row" style={styles.formRow}>
          <Field label="Tipo di investimento">
            <select value={modalitaInvestimento} onChange={(e) => setModalitaInvestimento(e.target.value)}>
              <option value="una_tantum">Una tantum (un'unica volta)</option>
              <option value="mensile">Mensile, senza scadenza</option>
              <option value="mensile_limitato">Mensile, per un periodo limitato</option>
            </select>
          </Field>
          <Field label="Inizia a investire da">
            <select value={meseInizioIdx} onChange={(e) => setMeseInizioIdx(Number(e.target.value))}>
              {proiezione.map((p, i) => <option key={i} value={i}>{p.label}</option>)}
            </select>
          </Field>
          {modalitaInvestimento === "mensile_limitato" && (
            <Field label="Durata (mesi)">
              <input type="number" min="1" value={durataMesiInvestimento} onChange={(e) => setDurataMesiInvestimento(Math.max(1, Number(e.target.value)))} style={{ width: 90 }} />
            </Field>
          )}
        </div>
        <p style={styles.hintText}>
          Utile se il punto piu' critico dell'orizzonte e' proprio adesso (es. un buco temporaneo nel conto libero professionista) ma la situazione migliora presto: scegliendo un mese di inizio successivo, i mesi precedenti non vengono considerati come vincolo, perche' non hai ancora prelevato nulla in quel periodo.
        </p>

        {modalitaInvestimento === "una_tantum" && (
          <p style={styles.hintText}>
            Se prelevi un importo da {proiezione[meseInizioIdx] ? proiezione[meseInizioIdx].label : "oggi"} per investirlo, il saldo di quel mese e di tutti i successivi scende della stessa cifra (i mesi precedenti non cambiano).
            L'importo massimo che puoi investire senza mai far scendere il saldo sotto la soglia critica e' quindi: saldo minimo da li' in poi ({fmtEUR((investimento.meseCritico ? investimento.meseCritico.saldo : 0))}, previsto a {investimento.meseCritico ? investimento.meseCritico.label : "-"}) meno soglia critica ({fmtEUR(settings.previsioneSogliaCritica)}).
          </p>
        )}
        {modalitaInvestimento === "mensile" && (
          <p style={styles.hintText}>
            Se investi ogni mese da {proiezione[meseInizioIdx] ? proiezione[meseInizioIdx].label : "oggi"} in poi, senza mai fermarti, l'effetto sul saldo si accumula: dopo N mesi dall'inizio hai gia' investito N rate, quindi il saldo di quel mese scende della cifra mensile moltiplicata per N.
            Il limite piu' stringente si trova di solito verso la fine dell'orizzonte, dove l'accumulo e' massimo: l'importo mensile sostenibile e' quello che, moltiplicato per i mesi trascorsi dall'inizio scelto, non fa mai scendere il saldo sotto la soglia critica.
          </p>
        )}
        {modalitaInvestimento === "mensile_limitato" && (
          <p style={styles.hintText}>
            Investi {fmtEUR(investimento.importo)} al mese per {durataMesiInvestimento} mesi a partire da {proiezione[meseInizioIdx] ? proiezione[meseInizioIdx].label : "oggi"}, poi ti fermi: l'importo gia' accantonato resta investito (non torna nel saldo familiare), ma da quel momento non ne aggiungi altro.
            Il vincolo piu' stringente puo' trovarsi durante il periodo di investimento (se il saldo cala rapidamente) oppure dopo, quando l'accumulo e' al massimo ma resta fisso.
          </p>
        )}

        <div style={{ fontFamily: "var(--font-mono)", fontSize: 24, fontWeight: 600, color: investimento.importo > 0 ? "var(--green)" : "var(--brick)" }}>
          {fmtEUR(investimento.importo)}{modalitaInvestimento !== "una_tantum" && "/mese"}
        </div>
        <p style={styles.hintText}>Il vincolo piu' stretto si verifica a {investimento.meseCritico ? investimento.meseCritico.label : "-"}.</p>
        {investimento.importo <= 0 && (
          <p style={styles.hintText}>Con le regole attuali e questa modalita' il saldo tocca o supera gia' la soglia critica entro l'orizzonte previsto: non c'e' margine per investimenti senza prima intervenire su entrate/uscite, cambiare modalita' o alzare la soglia.</p>
        )}
      </div>
    </div>
  );
}

function SettingsTab({ settings, updateSettings, resetAll, exportData, importData }) {
  const fileRef = useRef(null);
  return (
    <div>
      <SectionHeader title="Impostazioni" subtitle="Saldo di partenza e parametri generali del conto." />
      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Saldo di partenza</div>
        <div className="form-row" style={styles.formRow}>
          <Field label="Saldo alla data">
            <input type="number" step="0.01" value={settings.saldoIniziale} onChange={(e) => updateSettings({ saldoIniziale: Number(e.target.value) })} style={{ width: 140 }} />
          </Field>
          <Field label="Data di riferimento">
            <input type="date" value={settings.saldoInizialeData} onChange={(e) => updateSettings({ saldoInizialeData: e.target.value })} />
          </Field>
        </div>
        <p style={styles.hintText}>Il saldo di tutti i mesi viene calcolato a partire da questo valore, sommando o sottraendo ogni movimento successivo a questa data.</p>

        <label style={styles.checkRow}>
          <input
            type="checkbox"
            checked={settings.escludiStoricoDalSaldo}
            onChange={(e) => updateSettings({ escludiStoricoDalSaldo: e.target.checked })}
          />
          <span>Escludi dal saldo progressivo tutti i movimenti precedenti alla data di riferimento</span>
        </label>
        <p style={styles.hintText}>
          {settings.escludiStoricoDalSaldo
            ? "Attivo (default): il saldo iniziale e' un punto di partenza pulito, i movimenti datati prima di questa data non vengono conteggiati nel progressivo del saldo."
            : "Disattivato: anche i movimenti datati prima della data di riferimento concorrono al progressivo del saldo, sommati al saldo iniziale."}
        </p>
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Conteggio delle tasse (Libero professionista)</div>
        <p style={styles.hintText}>Indipendente dal reset del conto familiare qui sopra: puoi cambiare l'uno senza toccare l'altro.</p>
        <label style={styles.checkRow}>
          <input
            type="checkbox"
            checked={settings.includiStoricoPerTasse}
            onChange={(e) => updateSettings({ includiStoricoPerTasse: e.target.checked })}
          />
          <span>Considera comunque i movimenti precedenti nel conteggio delle tasse (fondo tasse, INPS, IRPEF)</span>
        </label>
        <p style={styles.hintText}>
          {settings.includiStoricoPerTasse
            ? "Attivo (default): il fatturato inserito prima della data di riferimento fiscale continua a contribuire ai totali di imposte, INPS e fondo tasse."
            : "Disattivato: il fatturato precedente alla data di riferimento fiscale resta visibile in tabella ma non viene piu' conteggiato nei totali di imposte, INPS e fondo tasse."}
        </p>
        {!settings.includiStoricoPerTasse && (
          <div className="form-row" style={styles.formRow}>
            <Field label="Data di riferimento fiscale">
              <input type="date" value={settings.dataRiferimentoTasse} onChange={(e) => updateSettings({ dataRiferimentoTasse: e.target.value })} />
            </Field>
          </div>
        )}
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Giorni di accredito</div>
        <div className="form-row" style={styles.formRow}>
          <Field label="Stipendio moglie">
            <input type="number" min="1" max="28" value={settings.giornoStipendioMoglie} onChange={(e) => updateSettings({ giornoStipendioMoglie: Number(e.target.value) })} style={{ width: 80 }} />
          </Field>
        </div>
        <p style={styles.hintText}>Il fatturato del libero professionista non genera piu' un movimento automatico sul conto familiare: usa un giroconto (nella scheda Libero professionista) per trasferire denaro dal conto professionale a quello familiare quando vuoi.</p>
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Regime IVA predefinito</div>
        <div className="form-row" style={styles.formRow}>
          <Field label="Regime proposto per le nuove voci di fatturato">
            <select value={settings.regimeDefault} onChange={(e) => updateSettings({ regimeDefault: e.target.value })}>
              <option value="forfettario">Forfettario</option>
              <option value="ordinario">Ordinario</option>
            </select>
          </Field>
        </div>
        <p style={styles.hintText}>Puoi comunque scegliere il regime per ogni singolo mese nella scheda Libero professionista: utile quando cambi regime da un anno all'altro.</p>
      </div>

      <div className="panel" style={styles.panel}>
        <div className="panel-title" style={styles.panelTitle}>Dati</div>
        <p style={styles.hintText}>I dati sono salvati automaticamente sul telefono e restano disponibili la prossima volta che apri l'app. Se disinstalli l'app o cambi telefono vanno persi: fai un backup ogni tanto.</p>
        <div className="btn-stack">
          <button style={styles.primaryBtn} onClick={exportData}><Download size={15} /> Esporta backup</button>
          <button style={styles.ghostBtn} onClick={() => fileRef.current && fileRef.current.click()}><Upload size={15} /> Ripristina da backup</button>
          <input
            ref={fileRef}
            type="file"
            style={{ display: "none" }}
            onChange={(e) => { importData(e.target.files && e.target.files[0]); e.target.value = ""; }}
          />
        </div>
        <p style={styles.hintText}>Il backup e' un file .json: puoi salvarlo su Drive, inviarlo per email o su WhatsApp e reimportarlo qui in qualsiasi momento.</p>
        <button style={styles.dangerBtn} onClick={resetAll}><Trash2 size={14} /> Cancella tutti i dati</button>
      </div>
    </div>
  );
}

function SectionHeader({ title, subtitle }) {
  // Su smartphone il titolo e' gia' nella barra in alto: qui resta la
  // descrizione, ridotta a due righe ed espandibile con un tocco.
  const [open, setOpen] = useState(false);
  const long = subtitle && subtitle.length > 90;
  return (
    <div className="section-header" style={{ marginBottom: 20 }}>
      <h1 style={styles.h1}>{title}</h1>
      {subtitle && (
        <p
          className={`section-sub${long ? " clampable" : ""}${open ? " open" : ""}`}
          style={styles.subtitle}
          onClick={long ? () => setOpen((o) => !o) : undefined}
        >
          {subtitle}
        </p>
      )}
      {long && (
        <button className="section-more" onClick={() => setOpen((o) => !o)}>
          {open ? "Mostra meno" : "Mostra tutto"} <ChevronDown size={14} style={{ transform: open ? "rotate(180deg)" : "none" }} />
        </button>
      )}
    </div>
  );
}

function MetricCard({ label, value, icon: Icon, tone }) {
  const color = tone === "green" ? "var(--green)" : tone === "brick" ? "var(--brick)" : "var(--ink)";
  return (
    <div className="metric-card" style={styles.metricCard}>
      <div style={styles.metricTop}>
        <span style={styles.metricLabel}>{label}</span>
        {Icon && <Icon size={15} color="var(--text-muted)" />}
      </div>
      <div className="metric-value" style={{ ...styles.metricValue, color }}>{value}</div>
    </div>
  );
}

// Tooltip personalizzato per il grafico del conto libero professionista:
// oltre a saldo e fondo tasse, elenca i singoli movimenti di quel mese
// (fatturato incassato, pagamenti tasse, spese professionali, giroconti)
// cosi' si puo' verificare a colpo d'occhio cosa ha inciso sul saldo.
function BusinessChartTooltip({ active, payload, label }) {
  if (!active || !payload || !payload.length) return null;
  const data = payload[0].payload;
  const movimenti = data.movimenti || [];
  return (
    <div style={styles.chartTooltip}>
      <div style={{ fontWeight: 600, marginBottom: 6 }}>{label}</div>
      <div style={{ color: "var(--green)" }}>Saldo reale: {fmtEUR(data.saldo)}</div>
      <div style={{ color: "var(--gold)" }}>Fondo tasse necessario: {fmtEUR(data.fondoTasse)}</div>
      {movimenti.length > 0 && (
        <div style={styles.chartTooltipMovimenti}>
          <div style={{ fontWeight: 600, marginBottom: 4 }}>Movimenti del mese</div>
          {movimenti.map((m, i) => (
            <div key={i} style={styles.chartTooltipRiga}>
              <span style={{ color: "var(--text-muted)" }}>
                {m.tipo}{m.dettaglio ? ` — ${m.dettaglio}` : ""}
              </span>
              <span style={{ fontFamily: "var(--font-mono)", color: m.importo >= 0 ? "var(--green)" : "var(--brick)", whiteSpace: "nowrap", marginLeft: 8 }}>
                {fmtEUR(m.importo)}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label style={styles.field}>
      <span style={styles.fieldLabel}>{label}</span>
      {children}
    </label>
  );
}

function YearFilter({ years, value, onChange }) {
  if (years.length <= 1) return null;
  return (
    <label style={styles.yearFilter}>
      <span style={styles.fieldLabel}>Anno</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">Tutti</option>
        {years.map((y) => <option key={y} value={y}>{y}</option>)}
      </select>
    </label>
  );
}

function RowActions({ onEdit, onDelete }) {
  // Su smartphone il modulo di modifica sta in cima al pannello, spesso
  // fuori schermo: dopo "Modifica" lo portiamo in vista e mettiamo il
  // cursore sul primo campo.
  const handleEdit = (e) => {
    const panel = e.currentTarget.closest(".panel");
    onEdit();
    haptic();
    if (!panel) return;
    setTimeout(() => {
      const rows = Array.from(panel.querySelectorAll(".form-row"));
      const form = rows.find((r) => r.querySelector("button")) || rows[0];
      if (form) form.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 30);
  };
  return (
    <span className="row-actions" style={{ display: "inline-flex", gap: 4 }}>
      {onEdit && <button className="iconbtn" style={styles.rowIconBtn} onClick={handleEdit} title="Modifica" aria-label="Modifica"><Pencil size={13} /></button>}
      {onDelete && <button className="iconbtn" style={styles.rowIconBtn} onClick={onDelete} title="Elimina" aria-label="Elimina"><Trash2 size={13} /></button>}
    </span>
  );
}

function EmptyState({ text }) {
  return <div style={styles.empty}>{text}</div>;
}

const styles = {
  app: {
    minHeight: "100dvh",
    background: "var(--paper)",
    fontFamily: "var(--font-body)",
    color: "var(--text)",
    "--ink": "#16324a",
    "--paper": "#F1F3EB",
    "--paper-alt": "#E7EADD",
    "--line": "#D9DACB",
    "--line-soft": "#E7E8DC",
    "--green": "#3C6E47",
    "--brick": "#A6402F",
    "--gold": "#B8862E",
    "--text": "#1F2A26",
    "--text-muted": "#767F71",
    "--font-body": "system-ui, -apple-system, Roboto, 'Segoe UI', Helvetica, Arial, sans-serif",
    "--font-display": "'Newsreader Variable', Georgia, 'Noto Serif', serif",
    // Importi in carattere normale con cifre tabellari (allineate in colonna):
    // piu' leggibile su smartphone di un monospaziato.
    "--font-mono": "system-ui, -apple-system, Roboto, 'Segoe UI', sans-serif",
  },
  layout: { display: "flex", minHeight: "100dvh" },
  sidebar: {
    width: 220,
    background: "var(--ink)",
    color: "#EDE7D8",
    display: "flex",
    flexDirection: "column",
    padding: "18px 12px",
    gap: 2,
    position: "sticky",
    top: 0,
    alignSelf: "flex-start",
    height: "100vh",
    overflowY: "auto",
  },
  brand: { display: "flex", alignItems: "center", gap: 10, padding: "4px 8px 20px" },
  brandTitle: { fontFamily: "var(--font-display)", fontSize: 17, lineHeight: 1.1 },
  brandSub: { fontSize: 11, opacity: 0.6, letterSpacing: ".03em" },
  navItem: {
    display: "flex", alignItems: "center", gap: 10, background: "transparent", border: "none",
    color: "#D8D3C2", padding: "9px 10px", borderRadius: 7, fontSize: 13.5, textAlign: "left",
  },
  navItemActive: { background: "rgba(255,255,255,0.14)", color: "#fff", fontWeight: 600 },
  fondoBadge: { background: "rgba(255,255,255,0.08)", borderRadius: 8, padding: "10px 12px", marginTop: 12 },
  main: { flex: 1, padding: "28px 32px", overflowX: "hidden", minWidth: 0 },
  h1: { fontFamily: "var(--font-display)", fontSize: 24, fontWeight: 400, margin: 0, color: "var(--ink)" },
  subtitle: { fontSize: 13.5, color: "var(--text-muted)", marginTop: 4 },
  cardsGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12, marginBottom: 20 },
  metricCard: { background: "#fff", border: "1px solid var(--line)", borderRadius: 10, padding: "14px 16px" },
  metricTop: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  metricLabel: { fontSize: 11.5, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: ".04em" },
  metricValue: { fontFamily: "var(--font-mono)", fontSize: 21, fontWeight: 600 },
  panel: { background: "#fff", border: "1px solid var(--line)", borderRadius: 10, padding: 18, marginBottom: 18 },
  panelTitle: { fontSize: 14, fontWeight: 600, color: "var(--ink)", marginBottom: 12 },
  panelHeadRow: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  formRow: { display: "flex", gap: 14, flexWrap: "wrap", alignItems: "flex-end", marginBottom: 16 },
  field: { display: "flex", flexDirection: "column", gap: 5 },
  yearFilter: { display: "flex", flexDirection: "column", gap: 5, marginBottom: 10 },
  chartTooltip: {
    background: "#fff", border: "1px solid var(--line)", borderRadius: 8, padding: "10px 12px",
    fontSize: 12, fontFamily: "var(--font-body)", maxWidth: 280, boxShadow: "0 4px 16px rgba(0,0,0,0.15)",
  },
  chartTooltipMovimenti: { marginTop: 8, borderTop: "1px solid var(--line-soft)", paddingTop: 6 },
  chartTooltipRiga: { display: "flex", justifyContent: "space-between", gap: 8, padding: "2px 0" },
  fieldLabel: { fontSize: 11, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: ".03em" },
  primaryBtn: {
    display: "inline-flex", alignItems: "center", gap: 6, background: "var(--ink)", color: "#fff",
    border: "none", borderRadius: 7, padding: "8px 14px", fontSize: 13, fontWeight: 600, height: 34,
  },
  ghostBtn: {
    display: "inline-flex", alignItems: "center", gap: 6, background: "transparent", color: "var(--text-muted)",
    border: "1px solid var(--line)", borderRadius: 7, padding: "8px 14px", fontSize: 13, height: 34,
  },
  dangerBtn: {
    display: "inline-flex", alignItems: "center", gap: 6, background: "#fff", color: "var(--brick)",
    border: "1px solid var(--brick)", borderRadius: 7, padding: "8px 14px", fontSize: 13, fontWeight: 600,
  },
  linkBtn: { background: "transparent", border: "none", color: "var(--gold)", fontSize: 12.5, fontWeight: 600, padding: 0 },
  rowIconBtn: { background: "transparent", border: "1px solid var(--line)", borderRadius: 6, padding: 5, display: "inline-flex" },
  iconBtn: { background: "transparent", border: "1px solid var(--line)", borderRadius: 7, padding: 6, display: "inline-flex" },
  monthNav: { display: "flex", alignItems: "center", gap: 10, marginBottom: 14 },
  monthLabel: { fontFamily: "var(--font-display)", fontSize: 17, minWidth: 160 },
  weekRow: { display: "grid", gridTemplateColumns: "repeat(7, 1fr)", marginBottom: 4 },
  weekLabel: { fontSize: 11, color: "var(--text-muted)", textAlign: "center", padding: "4px 0", textTransform: "uppercase", letterSpacing: ".03em" },
  calGrid: { display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4 },
  calCell: {
    minHeight: 78, background: "var(--paper-alt)", border: "1px solid var(--line)", borderRadius: 7,
    padding: 6, textAlign: "left", display: "flex", flexDirection: "column", gap: 3, alignItems: "flex-start",
    position: "relative", cursor: "pointer",
  },
  calCellEmpty: { minHeight: 78 },
  calCellToday: { borderColor: "var(--gold)", borderWidth: 1.5 },
  calCellSelected: { background: "#fff", boxShadow: "inset 0 0 0 2px var(--ink)" },
  calAddBtn: {
    position: "absolute", top: 4, right: 4, width: 16, height: 16, borderRadius: 4,
    background: "rgba(22,50,74,0.08)", border: "none", display: "flex", alignItems: "center",
    justifyContent: "center", color: "var(--ink)", padding: 0,
  },
  calDayNum: { fontSize: 12, fontWeight: 600, color: "var(--ink)" },
  calBadges: { display: "flex", flexDirection: "column", gap: 2 },
  calBadgeGreen: { fontFamily: "var(--font-mono)", fontSize: 10.5, color: "var(--green)" },
  calBadgeBrick: { fontFamily: "var(--font-mono)", fontSize: 10.5, color: "var(--brick)" },
  calBalance: { fontFamily: "var(--font-mono)", fontSize: 10.5, fontWeight: 600, marginTop: "auto" },
  empty: { padding: "20px 0", textAlign: "center", color: "var(--text-muted)", fontSize: 13 },
  hintText: { fontSize: 12.5, color: "var(--text-muted)", marginTop: 4, marginBottom: 12 },
  checkRow: { display: "flex", alignItems: "center", gap: 8, fontSize: 13, marginTop: 10, cursor: "pointer" },
  modalBackdrop: {
    position: "fixed", inset: 0, background: "rgba(22,30,26,0.45)", display: "flex",
    alignItems: "center", justifyContent: "center", zIndex: 50, padding: 16,
  },
  modalPanel: {
    background: "#fff", borderRadius: 12, padding: 20, width: "100%", maxWidth: 460,
    maxHeight: "88vh", overflowY: "auto", boxShadow: "0 12px 40px rgba(0,0,0,0.25)",
  },
  modalHeadRow: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14, gap: 8 },
  modalTypeRow: { display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 16 },
  modalFields: { display: "flex", flexDirection: "column", gap: 12, marginBottom: 16 },
  modalFooter: { display: "flex", justifyContent: "flex-end", gap: 8 },
  pillBtn: {
    background: "var(--paper-alt)", border: "1px solid var(--line)", borderRadius: 999,
    padding: "6px 12px", fontSize: 12, color: "var(--text)",
  },
  pillBtnActive: { background: "var(--ink)", borderColor: "var(--ink)", color: "#fff", fontWeight: 600 },
};

// ---------------------------------------------------------------------------
// Fogli di stile globali. Sopra gli 860px: layout desktop con barra laterale
// (tablet in orizzontale, browser). Sotto: layout smartphone con barra in
// alto, navigazione in basso, schede al posto delle tabelle, fogli dal basso.
// Le regole mobile usano !important perche' devono vincere sugli stili
// inline dei componenti.
// ---------------------------------------------------------------------------
const GLOBAL_CSS = `
  html, body { margin: 0; background: #F1F3EB; }
  body { -webkit-tap-highlight-color: transparent; -webkit-text-size-adjust: 100%; }
  .budget-root * { box-sizing: border-box; }
  .budget-root { font-variant-numeric: tabular-nums; }
  .budget-root input, .budget-root select {
    font-family: var(--font-body); font-size: 13px; padding: 7px 9px;
    border: 1px solid var(--line); border-radius: 6px; background: #fff; color: var(--text);
  }
  .budget-root input:focus, .budget-root select:focus { outline: 2px solid var(--gold); outline-offset: 1px; }
  .budget-root button { font-family: var(--font-body); cursor: pointer; }
  .budget-root button:focus-visible { outline: 2px solid var(--gold); outline-offset: 2px; }
  .budget-root table { width: 100%; border-collapse: collapse; font-size: 13px; }
  .budget-root th { text-align: left; font-weight: 600; color: var(--text-muted); font-size: 11px; text-transform: uppercase; letter-spacing: .04em; padding: 8px 10px; border-bottom: 1px solid var(--line); white-space: nowrap; }
  .budget-root td { padding: 8px 10px; border-bottom: 1px solid var(--line-soft); }
  .budget-root .num { font-family: var(--font-mono); text-align: right; font-variant-numeric: tabular-nums; }
  .budget-root .navbtn:hover { background: rgba(255,255,255,0.08); }
  .budget-root .iconbtn:hover { background: var(--paper-alt); }
  .budget-root table { display: block; overflow-x: auto; -webkit-overflow-scrolling: touch; }
  .budget-root thead, .budget-root tbody { display: table; width: 100%; min-width: 100%; }
  .budget-root .cal-cell { -webkit-user-select: none; user-select: none; -webkit-touch-callout: none; }
  .budget-root .form-error { color: var(--brick); font-size: 13px; margin: 0 0 12px; }
  .budget-root .btn-stack { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 8px; }
  .budget-root .section-more { display: none; }

  /* Elementi solo smartphone, nascosti su desktop */
  .m-header, .m-bottomnav, .fab, .only-mobile, .only-mobile-inline, .cal-dots { display: none !important; }

  /* Toast (conferme e "Annulla") */
  .toast {
    position: fixed; left: 50%; bottom: 24px; transform: translateX(-50%); z-index: 80;
    display: flex; align-items: center; gap: 16px; max-width: calc(100vw - 24px);
    background: #16324A; color: #F3EFE4; border-radius: 12px; padding: 12px 14px 12px 18px;
    font-size: 14.5px; box-shadow: 0 10px 30px rgba(22,50,74,.35);
    animation: toastIn .22s ease-out;
  }
  .toast button { background: transparent; border: 0; color: #E2B865; font-weight: 700; font-size: 14.5px; padding: 6px 4px; }
  @keyframes toastIn { from { opacity: 0; transform: translate(-50%, 12px); } to { opacity: 1; transform: translate(-50%, 0); } }

  /* Fogli dal basso */
  .sheet-backdrop { position: fixed; inset: 0; background: rgba(12,24,34,.48); z-index: 60; display: flex; align-items: flex-end; justify-content: center; animation: fadeIn .18s ease-out; }
  .sheet {
    background: #fff; width: 100%; max-width: 560px; border-radius: 22px 22px 0 0;
    padding: 8px 12px calc(16px + env(safe-area-inset-bottom, 0px));
    animation: sheetUp .26s cubic-bezier(.2,.9,.25,1); max-height: 90dvh; overflow-y: auto;
  }
  .sheet-handle { width: 38px; height: 4px; border-radius: 4px; background: #CFD3C6; margin: 4px auto 10px; }
  .sheet-title { font-family: var(--font-display); font-size: 19px; color: var(--ink); padding: 2px 8px 10px; }
  .sheet-list { display: flex; flex-direction: column; }
  .sheet-item { display: flex; align-items: center; gap: 14px; min-height: 58px; padding: 0 8px; background: transparent; border: 0; border-radius: 14px; font-size: 16px; color: var(--text); text-align: left; }
  .sheet-item:active { background: var(--paper); }
  .sheet-item.active .sheet-item-label { font-weight: 700; color: var(--ink); }
  .sheet-item-icon { width: 40px; height: 40px; border-radius: 12px; background: var(--paper); color: var(--ink); display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0; }
  .sheet-item.active .sheet-item-icon { background: var(--ink); color: var(--gold); }
  .sheet-item-label { flex: 1; }
  .sheet-item-chev { color: var(--text-muted); }
  @keyframes sheetUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
  @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

  @media (prefers-reduced-motion: reduce) {
    .sheet, .sheet-backdrop, .toast, .budget-root .modal-panel { animation: none !important; }
  }

  /* ======================= SMARTPHONE ======================= */
  @media (max-width: 860px) {
    html, body { background: #F1F3EB; overscroll-behavior-y: none; }
    .budget-root.layout { flex-direction: column !important; }
    .budget-root .sidebar { display: none !important; }
    .only-desktop { display: none !important; }
    .only-desktop-inline { display: none !important; }
    .only-mobile { display: block !important; }
    .only-mobile-inline { display: inline !important; }

    /* Barra superiore */
    .m-header {
      display: block !important; position: sticky; top: 0; z-index: 40;
      background: var(--ink); padding-top: env(safe-area-inset-top, 0px);
    }
    .m-topbar { height: 56px; display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 0 12px 0 18px; }
    .m-title { font-family: var(--font-display); font-size: 21px; color: #F3EFE4; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; letter-spacing: -.005em; }
    .m-balance {
      display: flex; flex-direction: column; align-items: flex-end; gap: 1px; flex-shrink: 0;
      background: rgba(255,255,255,.08); border: 0; border-radius: 12px; padding: 6px 12px; color: #F3EFE4;
    }
    .m-balance:active { background: rgba(255,255,255,.16); }
    .m-balance-label { font-size: 11px; opacity: .65; }
    .m-balance-value { font-size: 15px; font-weight: 650; color: #E2B865; }

    /* Barra di salto rapido tra i pannelli */
    .jumpbar {
      display: flex; gap: 8px; overflow-x: auto; padding: 10px 14px; scrollbar-width: none;
      background: var(--paper); border-bottom: 1px solid var(--line);
    }
    .jumpbar::-webkit-scrollbar { display: none; }
    .jumpchip {
      flex-shrink: 0; border: 1px solid var(--line); background: #fff; color: var(--text);
      border-radius: 999px; padding: 8px 14px; font-size: 13.5px; white-space: nowrap;
    }
    .jumpchip.active { background: var(--ink); border-color: var(--ink); color: #fff; font-weight: 600; }

    /* Contenuto */
    .budget-root .main-content { padding: 14px 12px calc(96px + env(safe-area-inset-bottom, 0px)) !important; overflow: visible !important; }
    .budget-root .panel { padding: 16px 14px !important; border-radius: 16px !important; margin-bottom: 14px !important; scroll-margin-top: calc(120px + env(safe-area-inset-top, 0px)); }
    .budget-root .panel-title { font-size: 16px !important; margin-bottom: 12px !important; }
    .budget-root .section-header { margin-bottom: 14px !important; }
    .budget-root .section-header h1 { display: none; }
    .budget-root .section-sub { font-size: 14px !important; line-height: 1.45; margin: 0 2px !important; }
    .budget-root .section-sub.clampable { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
    .budget-root .section-sub.clampable.open { display: block; }
    .budget-root .section-more { display: inline-flex; align-items: center; gap: 4px; background: none; border: 0; color: var(--gold); font-weight: 600; font-size: 13.5px; padding: 6px 2px 0; }
    .budget-root p { font-size: 13.5px; line-height: 1.45; }

    /* Schede riepilogo */
    .budget-root .cards { grid-template-columns: repeat(2, 1fr) !important; gap: 10px !important; margin-bottom: 14px !important; }
    .budget-root .metric-card { padding: 12px 14px !important; border-radius: 14px !important; }
    .budget-root .metric-value { font-size: 18px !important; letter-spacing: -.01em; }

    /* Moduli: campi a tutta larghezza, comodi da toccare */
    .budget-root input, .budget-root select {
      font-size: 16px !important; min-height: 48px; padding: 11px 12px !important;
      border-radius: 12px !important; width: 100% !important; max-width: 100%;
    }
    .budget-root input[type="checkbox"], .budget-root input[type="radio"] {
      width: 22px !important; min-height: 22px !important; height: 22px; padding: 0 !important; flex-shrink: 0; accent-color: var(--ink);
    }
    .budget-root select { -webkit-appearance: none; appearance: none; background-image: linear-gradient(45deg, transparent 50%, #767F71 50%), linear-gradient(135deg, #767F71 50%, transparent 50%); background-position: calc(100% - 18px) 21px, calc(100% - 13px) 21px; background-size: 5px 5px; background-repeat: no-repeat; padding-right: 32px !important; }
    .budget-root .form-row {
      display: grid !important; grid-template-columns: 1fr 1fr; gap: 12px !important; align-items: end !important;
    }
    .budget-root .form-row > * { min-width: 0; }
    .budget-root .form-row > label:has(input[type="text"]),
    .budget-root .form-row > button,
    .budget-root .form-row > p,
    .budget-root .form-row > div { grid-column: 1 / -1; }
    .budget-root .form-row > button { width: 100%; justify-content: center; }
    .budget-root label[style*="flex-direction: column"] > span:first-child { font-size: 12px !important; }
    .budget-root label[style] { gap: 6px !important; }
    .budget-root button[style*="height: 34"], .budget-root .btn-stack button, .budget-root .modal-footer button { min-height: 48px; height: auto !important; font-size: 15px !important; border-radius: 12px !important; justify-content: center; }
    .budget-root .btn-stack { flex-direction: column; }
    .budget-root .btn-stack button { width: 100%; }
    .budget-root button[style*="var(--brick)"] { min-height: 46px; border-radius: 12px !important; font-size: 15px !important; width: 100%; justify-content: center; }
    .budget-root .iconbtn { min-width: 40px; min-height: 40px; justify-content: center; align-items: center; border-radius: 12px !important; }
    .budget-root .row-actions { gap: 6px !important; }
    .budget-root .row-actions .iconbtn { min-width: 38px; min-height: 38px; background: #fff !important; }
    .budget-root label[style*="cursor: pointer"] { font-size: 14.5px !important; align-items: flex-start !important; gap: 12px !important; min-height: 44px; padding: 4px 0; }

    /* Tabelle -> schede impilate (etichette dalle intestazioni) */
    .budget-root table { display: block !important; overflow: visible !important; font-size: 14px; }
    .budget-root table thead { display: none !important; }
    .budget-root table tbody, .budget-root table tfoot { display: flex !important; flex-direction: column; gap: 10px; width: 100%; }
    .budget-root table tr {
      display: grid !important; grid-template-columns: 1fr 1fr; column-gap: 14px; row-gap: 10px;
      background: var(--paper); border-radius: 14px; padding: 12px 14px; position: relative;
    }
    .budget-root table td { display: flex !important; flex-direction: column; gap: 2px; border: 0 !important; padding: 0 !important; text-align: left !important; min-width: 0; word-break: break-word; }
    .budget-root table td::before { content: attr(data-label); font-size: 11.5px; color: var(--text-muted); font-family: var(--font-body); font-weight: 400; }
    .budget-root table td[data-label=""]::before { display: none; }
    .budget-root table td:first-child { grid-column: 1 / -1; font-weight: 650; font-size: 15.5px; color: var(--ink); padding-right: 92px !important; }
    .budget-root table td:first-child::before { display: none; }
    .budget-root table td.cell-actions { position: absolute; top: 8px; right: 8px; }
    .budget-root table td.cell-actions::before { display: none; }
    .budget-root table td.num { font-size: 15px; font-weight: 600; }
    .budget-root table td:empty { display: none !important; }

    /* Calendario */
    .budget-root .cal-grid { gap: 4px !important; }
    .budget-root .cal-cell { min-height: 58px !important; padding: 5px 4px 4px !important; border-radius: 11px !important; gap: 2px !important; align-items: center !important; }
    .budget-root .cal-cell:active { transform: scale(.96); }
    .budget-root .cal-addbtn, .budget-root .cal-badges { display: none !important; }
    .budget-root .cal-daynum { font-size: 14px !important; }
    .budget-root .cal-dots { display: flex !important; gap: 3px; height: 6px; }
    .budget-root .cal-dot { width: 6px; height: 6px; border-radius: 50%; display: block; }
    .budget-root .cal-dot.g { background: var(--green); }
    .budget-root .cal-dot.b { background: var(--brick); }
    .budget-root .cal-balance { font-size: 10.5px !important; margin-top: auto; }
    .budget-root .month-label { font-size: 19px !important; min-width: 0 !important; flex: 1; text-align: center; }

    /* Elenco movimenti stile app bancaria */
    .mov-list { margin: 0 -4px; }
    .mov-group + .mov-group { margin-top: 6px; }
    .mov-day { display: flex; justify-content: space-between; align-items: baseline; padding: 10px 4px 6px; font-size: 13px; color: var(--text-muted); }
    .mov-day span:first-child::first-letter { text-transform: uppercase; }
    .mov-day-bal { font-size: 12.5px; }
    .mov-item { display: flex; align-items: center; gap: 12px; padding: 10px 4px; border-top: 1px solid var(--line-soft); }
    .mov-icon { width: 38px; height: 38px; border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .mov-icon.g { background: #E2ECDF; color: var(--green); }
    .mov-icon.b { background: #F2E1DC; color: var(--brick); }
    .mov-text { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px; }
    .mov-desc { font-size: 15px; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .mov-cat { font-size: 12.5px; color: var(--text-muted); }
    .mov-amt { font-size: 15.5px; font-weight: 650; white-space: nowrap; }
    .mov-amt.g { color: var(--green); }
    .mov-amt.b { color: var(--text); }

    /* Finestra "aggiungi movimento" -> foglio dal basso */
    .budget-root .modal-backdrop { align-items: flex-end !important; padding: 0 !important; animation: fadeIn .18s ease-out; }
    .budget-root .modal-panel {
      max-width: none !important; border-radius: 22px 22px 0 0 !important; max-height: 94dvh !important;
      padding: 8px 16px 0 !important; animation: sheetUp .26s cubic-bezier(.2,.9,.25,1);
    }
    .budget-root .modal-type-row { flex-wrap: nowrap !important; overflow-x: auto; margin: 0 -16px 16px !important; padding: 0 16px; scrollbar-width: none; }
    .budget-root .modal-type-row::-webkit-scrollbar { display: none; }
    .budget-root .modal-type-row button { flex-shrink: 0; padding: 9px 14px !important; font-size: 14px !important; white-space: nowrap; }
    .budget-root .modal-footer {
      position: sticky; bottom: 0; background: #fff; margin: 0 -16px; padding: 12px 16px calc(12px + env(safe-area-inset-bottom, 0px)) !important;
      border-top: 1px solid var(--line-soft);
    }
    .budget-root .modal-footer button { flex: 1; }

    /* Navigazione in basso */
    .m-bottomnav {
      display: flex !important; position: fixed; left: 0; right: 0; bottom: 0; z-index: 45;
      background: var(--ink); padding: 6px 4px calc(6px + env(safe-area-inset-bottom, 0px));
      box-shadow: 0 -1px 0 rgba(255,255,255,.04);
    }
    .m-navbtn { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px; background: none; border: 0; padding: 4px 0; color: #A9B6BF; min-height: 56px; }
    .m-navicon { width: 60px; height: 32px; border-radius: 16px; display: inline-flex; align-items: center; justify-content: center; transition: background .2s; }
    .m-navbtn.active { color: #fff; }
    .m-navbtn.active .m-navicon { background: rgba(184,134,46,.28); color: #E9C27A; }
    .m-navbtn:active .m-navicon { background: rgba(255,255,255,.1); }
    .m-navlabel { font-size: 11.5px; letter-spacing: .01em; }
    .m-navbtn.active .m-navlabel { font-weight: 700; }

    /* Pulsante flottante "Nuovo" */
    .fab {
      display: inline-flex !important; align-items: center; gap: 8px; position: fixed; z-index: 44;
      right: 16px; bottom: calc(84px + env(safe-area-inset-bottom, 0px));
      height: 56px; padding: 0 20px 0 16px; border-radius: 18px; border: 0;
      background: var(--gold); color: #16324A; font-size: 15.5px; font-weight: 700;
      box-shadow: 0 6px 18px rgba(184,134,46,.45), 0 2px 4px rgba(22,50,74,.2);
    }
    .fab:active { transform: scale(.96); }

    .toast { bottom: calc(150px + env(safe-area-inset-bottom, 0px)); width: calc(100vw - 24px); justify-content: space-between; }
  }

  @media (max-width: 380px) {
    .budget-root .form-row { grid-template-columns: 1fr; }
    .m-navlabel { font-size: 10.5px; }
    .m-navicon { width: 52px; }
    .budget-root .metric-value { font-size: 16px !important; }
  }
`;
