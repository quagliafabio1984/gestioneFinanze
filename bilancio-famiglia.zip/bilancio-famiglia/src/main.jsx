import React from "react";
import { createRoot } from "react-dom/client";
import { Capacitor } from "@capacitor/core";
import { Preferences } from "@capacitor/preferences";
import { StatusBar, Style } from "@capacitor/status-bar";
import "@fontsource-variable/newsreader";
import App from "./App.jsx";

// ---------------------------------------------------------------------------
// window.storage: stessa API asincrona usata dall'app nell'ambiente Claude
// (get/set/delete/list), qui implementata con le Preferences native di
// Android (SharedPreferences: sopravvivono alla pulizia della cache della
// WebView) e una copia in localStorage, usata anche nel browser.
// ---------------------------------------------------------------------------
const PREFIX = "bilancio-famiglia:";
const native = Capacitor.isNativePlatform();
const ls = {
  get: (k) => { try { return localStorage.getItem(PREFIX + k); } catch { return null; } },
  set: (k, v) => { try { localStorage.setItem(PREFIX + k, v); } catch { /* quota */ } },
  del: (k) => { try { localStorage.removeItem(PREFIX + k); } catch { /* ignore */ } },
};

window.storage = {
  async get(key) {
    let value = null;
    if (native) value = (await Preferences.get({ key: PREFIX + key })).value;
    if (value == null) value = ls.get(key);
    return value == null ? null : { key, value, shared: false };
  },
  async set(key, value) {
    if (native) await Preferences.set({ key: PREFIX + key, value });
    ls.set(key, value);
    return { key, value, shared: false };
  },
  async delete(key) {
    if (native) await Preferences.remove({ key: PREFIX + key });
    ls.del(key);
    return { key, deleted: true, shared: false };
  },
  async list(prefix = "") {
    let keys = [];
    if (native) keys = (await Preferences.keys()).keys;
    else { try { keys = Object.keys(localStorage); } catch { keys = []; } }
    keys = keys.filter((k) => k.startsWith(PREFIX)).map((k) => k.slice(PREFIX.length)).filter((k) => k.startsWith(prefix));
    return { keys, prefix, shared: false };
  },
};

if (native) {
  StatusBar.setOverlaysWebView({ overlay: false }).catch(() => {});
  StatusBar.setBackgroundColor({ color: "#16324A" }).catch(() => {});
  StatusBar.setStyle({ style: Style.Dark }).catch(() => {});
}

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
