# Bilancio di famiglia — app Android

App per smartphone generata da `src/App.jsx` (React) e impacchettata con
Capacitor. L'APK viene compilato automaticamente da **GitHub Actions**: non
serve installare Android Studio.

## 1. Primo caricamento su GitHub

1. Su github.com crea un nuovo repository **privato** (es. `bilancio-famiglia`).
   Privato perché contiene la chiave con cui viene firmata l'app.
2. **Add file → Upload files**: carica il file `bilancio-famiglia.zip` così
   com'è, senza estrarlo, e fai **Commit changes**.
3. **Add file → Create new file**: come nome scrivi
   `.github/workflows/build-apk.yml`, incolla il contenuto del file
   `build-apk.yml` e fai **Commit changes**.
4. Nella scheda **Actions** parte "Build APK" (5-8 minuti): estrae lo zip,
   compila e firma l'APK.

## 2. Installare sul telefono

1. Dal telefono apri il repository → **Releases** (colonna di destra) →
   ultima versione → tocca `Bilancio-1.0.N.apk`.
2. Apri il file scaricato. La prima volta Android chiede di consentire
   l'installazione da questa fonte (Chrome o File): consenti e installa.

L'APK si trova anche in **Actions → ultima esecuzione → Artifacts** (zippato).

## 3. Aggiornare l'app

Sostituisci `bilancio-famiglia.zip` nel repository con la nuova versione
(Add file → Upload files, stesso nome) e fai commit: parte una nuova build con numero di versione più alto. Installando il
nuovo APK sopra quello vecchio **i dati restano**, perché ogni build è firmata
sempre con la stessa chiave (`keystore/bilancio.jks`).

> Non cancellare né sostituire `keystore/bilancio.jks`: con una chiave diversa
> Android rifiuta l'aggiornamento e bisognerebbe disinstallare, perdendo i dati.

## 4. Backup dei dati

I dati stanno solo sul telefono (memoria interna dell'app). In
**Altro → Impostazioni → Dati** trovi:

- **Esporta backup**: crea un file `.json` e apre il menu Condividi (Drive,
  email, WhatsApp...).
- **Ripristina da backup**: reimporta un file esportato in precedenza.

## Cosa è cambiato rispetto alla versione desktop

- Barra di navigazione in basso (Calendario, Partita IVA, Uscite, Previsioni,
  Altro) e intestazione con il saldo del conto professionale sempre visibile.
- Calendario a celle grandi con pallini entrate/uscite e saldo in migliaia;
  tocca un giorno per filtrare, tienilo premuto o usa il pulsante **Nuovo**.
- Movimenti del mese raggruppati per giorno come nelle app bancarie.
- Tabelle trasformate in schede leggibili; moduli con campi grandi a tutta
  larghezza (niente zoom automatico della tastiera).
- "Aggiungi movimento" come foglio che sale dal basso.
- Eliminazione con **Annulla** per qualche secondo; "Modifica" porta in vista il
  modulo già compilato.
- Barra di salto rapido tra i pannelli nelle schede lunghe.
- Tasto Indietro di Android: chiude il foglio aperto, poi torna al Calendario,
  poi esce.
- Feedback aptico, barre di sistema e schermata di avvio nei colori dell'app.
- Su schermi larghi (tablet in orizzontale, browser) resta il layout con barra
  laterale. Calcoli fiscali e logica dei conti invariati.

## Struttura

```
src/App.jsx                    l'app (file unico, come la versione originale)
src/main.jsx                   avvio, salvataggio dati nativo, barra di stato
android-res/                   icone e tema Android copiati nella build
scripts/customize-android.sh   personalizza il progetto Android in CI
scripts/make_icons.py          rigenera le icone (Python + Pillow)
keystore/bilancio.jks          chiave di firma (non modificare)
```

## Facoltativo

- **Provare nel browser** dal PC: `npm install` e poi `npm run dev`.
- **Chiave nei Secrets invece che nel repository**: in Settings → Secrets and
  variables → Actions crea `KEYSTORE_BASE64` (il file .jks in base64),
  `KEYSTORE_PASSWORD` e `KEY_ALIAS`; il workflow le usa al posto della chiave
  inclusa. Usa la stessa chiave di sempre, altrimenti l'aggiornamento non si
  installa.
