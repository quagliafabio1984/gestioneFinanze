# Genera le icone dell'app (launcher Android + PWA) a partire da un disegno
# vettoriale semplice: tempietto/"landmark" oro su blu inchiostro.
from PIL import Image, ImageDraw
import os
INK = (22, 50, 74, 255)
GOLD = (214, 166, 74, 255)
S = 4096  # disegno ad alta risoluzione, poi ridotto (antialias)

def glyph(draw, cx, cy, size):
    # size = larghezza totale del simbolo
    w = size; u = w / 20.0
    top = cy - 9 * u
    # frontone
    draw.polygon([(cx - 10*u, top + 5*u), (cx, top), (cx + 10*u, top + 5*u)], fill=GOLD)
    draw.rectangle([cx - 10*u, top + 5*u, cx + 10*u, top + 6.6*u], fill=GOLD)
    # colonne
    col_w = 2.0*u; gap = (20*u - 4*col_w) / 5
    y0, y1 = top + 7.8*u, top + 14.6*u
    for i in range(4):
        x = cx - 10*u + gap*(i+1) + col_w*i
        draw.rounded_rectangle([x, y0, x + col_w, y1], radius=0.4*u, fill=GOLD)
    # basamento a gradini
    draw.rectangle([cx - 10*u, top + 15.8*u, cx + 10*u, top + 17.2*u], fill=GOLD)
    draw.rectangle([cx - 11*u, top + 18.0*u, cx + 11*u, top + 19.4*u], fill=GOLD)

def full_icon(shape):
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    if shape == "square":
        d.rectangle([0, 0, S, S], fill=INK)
    elif shape == "rounded":
        d.rounded_rectangle([int(S*.04), int(S*.04), int(S*.96), int(S*.96)], radius=int(S*.22), fill=INK)
    elif shape == "round":
        d.ellipse([int(S*.04), int(S*.04), int(S*.96), int(S*.96)], fill=INK)
    glyph(d, S/2, S/2 + S*0.005, S*0.50)
    return im

def foreground():
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    glyph(d, S/2, S/2 + S*0.004, S*0.40)  # dentro la zona sicura (66%) dell'adaptive icon
    return im

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
res = os.path.join(root, "android-res")
dens = {"mdpi": 1, "hdpi": 1.5, "xhdpi": 2, "xxhdpi": 3, "xxxhdpi": 4}
rounded, rnd, fg = full_icon("rounded"), full_icon("round"), foreground()
for name, k in dens.items():
    d = os.path.join(res, f"mipmap-{name}"); os.makedirs(d, exist_ok=True)
    rounded.resize((int(48*k),)*2, Image.LANCZOS).save(os.path.join(d, "ic_launcher.png"))
    rnd.resize((int(48*k),)*2, Image.LANCZOS).save(os.path.join(d, "ic_launcher_round.png"))
    fg.resize((int(108*k),)*2, Image.LANCZOS).save(os.path.join(d, "ic_launcher_foreground.png"))
pub = os.path.join(root, "public"); os.makedirs(pub, exist_ok=True)
sq = full_icon("square")
for px in (192, 512):
    sq.resize((px, px), Image.LANCZOS).save(os.path.join(pub, f"icon-{px}.png"))
os.makedirs(os.path.join(root, "resources"), exist_ok=True)
rounded.resize((1024, 1024), Image.LANCZOS).save(os.path.join(root, "resources", "icon-preview.png"))
print("icone generate")
