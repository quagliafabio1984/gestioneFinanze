#!/usr/bin/env bash
# Personalizza il progetto Android generato da "npx cap add android":
# icone, tema/colori barre di sistema, tastiera, versione.
# Uso: bash scripts/customize-android.sh <numero_build>
set -euo pipefail
BUILD="${1:-1}"
A=android
RES="$A/app/src/main/res"

echo "> Icone e tema"
cp -r android-res/. "$RES/"

echo "> targetSdk 34 (barre di sistema classiche, niente edge-to-edge forzato di Android 15)"
sed -i -E 's/targetSdkVersion = [0-9]+/targetSdkVersion = 34/' "$A/variables.gradle"
grep -E "SdkVersion" "$A/variables.gradle" || true

echo "> Versione 1.0.$BUILD (versionCode $BUILD): ogni build aggiorna la precedente senza perdere i dati"
sed -i -E "s/versionCode [0-9]+/versionCode $BUILD/; s/versionName \"[^\"]*\"/versionName \"1.0.$BUILD\"/" "$A/app/build.gradle"
grep -E "versionCode|versionName" "$A/app/build.gradle" || true

echo "> Tastiera: ridimensiona la pagina invece di coprire i campi"
M="$A/app/src/main/AndroidManifest.xml"
if ! grep -q windowSoftInputMode "$M"; then
  sed -i 's/android:launchMode="singleTask"/android:launchMode="singleTask" android:windowSoftInputMode="adjustResize"/' "$M"
fi
grep -o 'windowSoftInputMode="[a-zA-Z]*"' "$M" || echo "(windowSoftInputMode non impostato)"
