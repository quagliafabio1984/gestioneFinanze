import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// base "./": percorsi relativi, necessari dentro la WebView di Capacitor.
export default defineConfig({
  plugins: [react()],
  base: "./",
  build: { outDir: "dist", chunkSizeWarningLimit: 2000 },
});
